%% set path & load data
DataPath = 'C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\rawHFOResults';
addpath(genpath(DataPath))
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\rawHFOResults')
load('ContactsFinal.mat')
load('LabelName.mat')
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data')
load('SOZLabel.mat')
PT = textread('PTlist.txt','%s');

cd(DataPath)
FileRaw = dir('*.mat');

%% calculate R value
% nonSOZ channel
for j = 1 : length(PT)
    % awake 1
    load(FileRaw(4*j-3).name)
    HFOstereo_nonSOZ.(PT{j}) = cell(length(RawResults.RawHFO),9);
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOstereo_nonSOZ.(PT{j}){i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6
                HFOstereo_nonSOZ.(PT{j}){i,2} = RawResults.RawHFO{i};
                % filter
                BdFreq = [3];
                fs = 2000;
                Dfilt_nonSOZ.(PT{j}){i} = highpass([HFOstereo_nonSOZ.(PT{j}){i,2}]',BdFreq,fs);
                Dfilt_nonSOZ.(PT{j}){i} = Dfilt_nonSOZ.(PT{j}){i}(400:801,:);
                
                % create HFO template
                HFOtemplate_nonSOZ.(PT{j}){i} = mean(Dfilt_nonSOZ.(PT{j}){i},2);
                
                % calculate correlation
                for k = 1:size(Dfilt_nonSOZ.(PT{j}){i},2)
                    [rho_nonSOZ.(PT{j}){i}(k),~] = corr(Dfilt_nonSOZ.(PT{j}){i}(:,k),HFOtemplate_nonSOZ.(PT{j}){i});
                end
                % calculate average R
                HFOstereo_nonSOZ.(PT{j}){i,3} = mean(rho_nonSOZ.(PT{j}){i});
            end
        end
    end
    % awake 2
    load(FileRaw(4*j-2).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1
            if size(RawResults.RawHFO{i},1) >= 6
                HFOstereo_nonSOZ.(PT{j}){i,4} = RawResults.RawHFO{i};
                % filter
                BdFreq = [3];
                fs = 2000;
                Dfilt_nonSOZ.(PT{j}){i} = highpass([HFOstereo_nonSOZ.(PT{j}){i,4}]',BdFreq,fs);
                Dfilt_nonSOZ.(PT{j}){i} = Dfilt_nonSOZ.(PT{j}){i}(400:801,:);
                
                % create HFO template
                HFOtemplate_nonSOZ.(PT{j}){i} = mean(Dfilt_nonSOZ.(PT{j}){i},2);
                
                % calculate correlation
                for k = 1:size(Dfilt_nonSOZ.(PT{j}){i},2)
                    [rho_nonSOZ.(PT{j}){i}(k),~] = corr(Dfilt_nonSOZ.(PT{j}){i}(:,k),HFOtemplate_nonSOZ.(PT{j}){i});
                end
                % calculate average R
                HFOstereo_nonSOZ.(PT{j}){i,5} = mean(rho_nonSOZ.(PT{j}){i});
            end
        end
    end
    % sleep 1
    load(FileRaw(4*j-1).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1
            if size(RawResults.RawHFO{i},1) >= 6
                HFOstereo_nonSOZ.(PT{j}){i,6} = RawResults.RawHFO{i};
                % filter
                BdFreq = [3];
                fs = 2000;
                Dfilt_nonSOZ.(PT{j}){i} = highpass([HFOstereo_nonSOZ.(PT{j}){i,6}]',BdFreq,fs);
                Dfilt_nonSOZ.(PT{j}){i} = Dfilt_nonSOZ.(PT{j}){i}(400:801,:);
                
                % create HFO template
                HFOtemplate_nonSOZ.(PT{j}){i} = mean(Dfilt_nonSOZ.(PT{j}){i},2);
                
                % calculate correlation
                for k = 1:size(Dfilt_nonSOZ.(PT{j}){i},2)
                    [rho_nonSOZ.(PT{j}){i}(k),~] = corr(Dfilt_nonSOZ.(PT{j}){i}(:,k),HFOtemplate_nonSOZ.(PT{j}){i});
                end
                % calculate average R
                HFOstereo_nonSOZ.(PT{j}){i,7} = mean(rho_nonSOZ.(PT{j}){i});
            end
        end
    end
    % sleep 2
    load(FileRaw(4*j).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1
            if size(RawResults.RawHFO{i},1) >= 6
                HFOstereo_nonSOZ.(PT{j}){i,8} = RawResults.RawHFO{i};
                % filter
                BdFreq = [3];
                fs = 2000;
                Dfilt_nonSOZ.(PT{j}){i} = highpass([HFOstereo_nonSOZ.(PT{j}){i,8}]',BdFreq,fs);
                Dfilt_nonSOZ.(PT{j}){i} = Dfilt_nonSOZ.(PT{j}){i}(400:801,:);
                
                % create HFO template
                HFOtemplate_nonSOZ.(PT{j}){i} = mean(Dfilt_nonSOZ.(PT{j}){i},2);
                
                % calculate correlation
                for k = 1:size(Dfilt_nonSOZ.(PT{j}){i},2)
                    [rho_nonSOZ.(PT{j}){i}(k),~] = corr(Dfilt_nonSOZ.(PT{j}){i}(:,k),HFOtemplate_nonSOZ.(PT{j}){i});
                end
                % calculate average R
                HFOstereo_nonSOZ.(PT{j}){i,9} = mean(rho_nonSOZ.(PT{j}){i});
            end
        end
    end
end

% SOZ channel
for j = 1 : length(PT)
    % awake 1
    load(FileRaw(4*j-3).name)
    HFOstereo_SOZ.(PT{j}) = cell(length(RawResults.RawHFO),9);
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOstereo_SOZ.(PT{j}){i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6
                HFOstereo_SOZ.(PT{j}){i,2} = RawResults.RawHFO{i};
                % filter
                BdFreq = [3];
                fs = 2000;
                Dfilt_SOZ.(PT{j}){i} = highpass([HFOstereo_SOZ.(PT{j}){i,2}]',BdFreq,fs);
                Dfilt_SOZ.(PT{j}){i} = Dfilt_SOZ.(PT{j}){i}(400:801,:);
                
                % create HFO template
                HFOtemplate_SOZ.(PT{j}){i} = mean(Dfilt_SOZ.(PT{j}){i},2);
                
                % calculate correlation
                for k = 1:size(Dfilt_SOZ.(PT{j}){i},2)
                    [rho_SOZ.(PT{j}){i}(k),~] = corr(Dfilt_SOZ.(PT{j}){i}(:,k),HFOtemplate_SOZ.(PT{j}){i});
                end
                % calculate average R
                HFOstereo_SOZ.(PT{j}){i,3} = mean(rho_SOZ.(PT{j}){i});
            end
        end
    end
    % awake 2
    load(FileRaw(4*j-2).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1
            if size(RawResults.RawHFO{i},1) >= 6
                HFOstereo_SOZ.(PT{j}){i,4} = RawResults.RawHFO{i};
                % filter
                BdFreq = [3];
                fs = 2000;
                Dfilt_SOZ.(PT{j}){i} = highpass([HFOstereo_SOZ.(PT{j}){i,4}]',BdFreq,fs);
                Dfilt_SOZ.(PT{j}){i} = Dfilt_SOZ.(PT{j}){i}(400:801,:);
                
                % create HFO template
                HFOtemplate_SOZ.(PT{j}){i} = mean(Dfilt_SOZ.(PT{j}){i},2);
                
                % calculate correlation
                for k = 1:size(Dfilt_SOZ.(PT{j}){i},2)
                    [rho_SOZ.(PT{j}){i}(k),~] = corr(Dfilt_SOZ.(PT{j}){i}(:,k),HFOtemplate_SOZ.(PT{j}){i});
                end
                % calculate average R
                HFOstereo_SOZ.(PT{j}){i,5} = mean(rho_SOZ.(PT{j}){i});
            end
        end
    end
    % sleep 1
    load(FileRaw(4*j-1).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1
            if size(RawResults.RawHFO{i},1) >= 6
                HFOstereo_SOZ.(PT{j}){i,6} = RawResults.RawHFO{i};
                % filter
                BdFreq = [3];
                fs = 2000;
                Dfilt_SOZ.(PT{j}){i} = highpass([HFOstereo_SOZ.(PT{j}){i,6}]',BdFreq,fs);
                Dfilt_SOZ.(PT{j}){i} = Dfilt_SOZ.(PT{j}){i}(400:801,:);
                
                % create HFO template
                HFOtemplate_SOZ.(PT{j}){i} = mean(Dfilt_SOZ.(PT{j}){i},2);
                
                % calculate correlation
                for k = 1:size(Dfilt_SOZ.(PT{j}){i},2)
                    [rho_SOZ.(PT{j}){i}(k),~] = corr(Dfilt_SOZ.(PT{j}){i}(:,k),HFOtemplate_SOZ.(PT{j}){i});
                end
                % calculate average R
                HFOstereo_SOZ.(PT{j}){i,7} = mean(rho_SOZ.(PT{j}){i});
            end
        end
    end
    % sleep 2
    load(FileRaw(4*j).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1
            if size(RawResults.RawHFO{i},1) >= 6
                HFOstereo_SOZ.(PT{j}){i,8} = RawResults.RawHFO{i};
                % filter
                BdFreq = [3];
                fs = 2000;
                Dfilt_SOZ.(PT{j}){i} = highpass([HFOstereo_SOZ.(PT{j}){i,8}]',BdFreq,fs);
                Dfilt_SOZ.(PT{j}){i} = Dfilt_SOZ.(PT{j}){i}(400:801,:);
                
                % create HFO template
                HFOtemplate_SOZ.(PT{j}){i} = mean(Dfilt_SOZ.(PT{j}){i},2);
                
                % calculate correlation
                for k = 1:size(Dfilt_SOZ.(PT{j}){i},2)
                    [rho_SOZ.(PT{j}){i}(k),~] = corr(Dfilt_SOZ.(PT{j}){i}(:,k),HFOtemplate_SOZ.(PT{j}){i});
                end
                % calculate average R
                HFOstereo_SOZ.(PT{j}){i,9} = mean(rho_SOZ.(PT{j}){i});
            end
        end
    end
end

%% settle data
% SOZ
HFO_stereo_SOZWhole =[];
for i = 1 : length(PT)
    for j = 1 : size(HFOstereo_SOZ.(PT{i}),1)
        if isempty(HFOstereo_SOZ.(PT{i}){j, 1}) ~= 1
            HFO_stereo_SOZWhole =[HFO_stereo_SOZWhole;HFOstereo_SOZ.(PT{i})(j, :)];
        end
    end
end
HFO_stereo_SOZWholeFinal = cell(size(HFO_stereo_SOZWhole,1),3);
HFO_stereo_SOZWholeFinal(:,1) = HFO_stereo_SOZWhole(:,1);
for k = 1 : size(HFO_stereo_SOZWhole,1)
    % col2: awake data
    indicator = isempty(HFO_stereo_SOZWhole{k,3}) + isempty(HFO_stereo_SOZWhole{k,5});
    switch indicator
        case 2
            HFO_stereo_SOZWholeFinal{k,2} = [];
        case 0
            HFO_stereo_SOZWholeFinal{k,2} = mean([HFO_stereo_SOZWhole{k,3},HFO_stereo_SOZWhole{k,5}]);
        case 1
            if isempty(HFO_stereo_SOZWhole{k,3}) == 1
                HFO_stereo_SOZWholeFinal{k,2} = HFO_stereo_SOZWhole{k,5};
            else 
                HFO_stereo_SOZWholeFinal{k,2} = HFO_stereo_SOZWhole{k,3};
            end
    end
    % col3: sleep data
    indicator = isempty(HFO_stereo_SOZWhole{k,7}) + isempty(HFO_stereo_SOZWhole{k,9});
    switch indicator
        case 2
            HFO_stereo_SOZWholeFinal{k,3} = [];
        case 0
            HFO_stereo_SOZWholeFinal{k,3} = mean([HFO_stereo_SOZWhole{k,7},HFO_stereo_SOZWhole{k,9}]);
        case 1
            if isempty(HFO_stereo_SOZWhole{k,7}) == 1
                HFO_stereo_SOZWholeFinal{k,3} = HFO_stereo_SOZWhole{k,9};
            else 
                HFO_stereo_SOZWholeFinal{k,3} = HFO_stereo_SOZWhole{k,7};
            end
    end
end

% nonSOZ
HFO_stereo_nonSOZWhole =[];
for i = 1 : length(PT)
    for j = 1 : size(HFOstereo_nonSOZ.(PT{i}),1)
        if isempty(HFOstereo_nonSOZ.(PT{i}){j, 1}) ~= 1
            HFO_stereo_nonSOZWhole =[HFO_stereo_nonSOZWhole;HFOstereo_nonSOZ.(PT{i})(j, :)];
        end
    end
end
HFO_stereo_nonSOZWholeFinal = cell(size(HFO_stereo_nonSOZWhole,1),3);
HFO_stereo_nonSOZWholeFinal(:,1) = HFO_stereo_nonSOZWhole(:,1);
for k = 1 : size(HFO_stereo_nonSOZWhole,1)
    % col2: awake data
    indicator = isempty(HFO_stereo_nonSOZWhole{k,3}) + isempty(HFO_stereo_nonSOZWhole{k,5});
    switch indicator
        case 2
            HFO_stereo_nonSOZWholeFinal{k,2} = [];
        case 0
            HFO_stereo_nonSOZWholeFinal{k,2} = mean([HFO_stereo_nonSOZWhole{k,3},HFO_stereo_nonSOZWhole{k,5}]);
        case 1
            if isempty(HFO_stereo_nonSOZWhole{k,3}) == 1
                HFO_stereo_nonSOZWholeFinal{k,2} = HFO_stereo_nonSOZWhole{k,5};
            else 
                HFO_stereo_nonSOZWholeFinal{k,2} = HFO_stereo_nonSOZWhole{k,3};
            end
    end
    % col3: sleep data
    indicator = isempty(HFO_stereo_nonSOZWhole{k,7}) + isempty(HFO_stereo_nonSOZWhole{k,9});
    switch indicator
        case 2
            HFO_stereo_nonSOZWholeFinal{k,3} = [];
        case 0
            HFO_stereo_nonSOZWholeFinal{k,3} = mean([HFO_stereo_nonSOZWhole{k,7},HFO_stereo_nonSOZWhole{k,9}]);
        case 1
            if isempty(HFO_stereo_nonSOZWhole{k,7}) == 1
                HFO_stereo_nonSOZWholeFinal{k,3} = HFO_stereo_nonSOZWhole{k,9};
            else 
                HFO_stereo_nonSOZWholeFinal{k,3} = HFO_stereo_nonSOZWhole{k,7};
            end
    end
end

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\awake_sleep_data')
save('stereotype_SOZ.mat','HFO_stereo_SOZWholeFinal')
save('stereotype_nonSOZ.mat','HFO_stereo_nonSOZWholeFinal')

%%
figure
% plot orignal data
subplot(3,1,1)
plot(HFOstereo_nonSOZ.GuoZiqi{16, 8}')
set(gca,'XLim',[0 1201])
% plot HFO template
subplot(3,1,2)
plot(Dfilt_nonSOZ.GuoZiqi{1, 16},'Color',[0.705882352941177	0.749019607843137	0.756862745098039])
hold on
plot(mean(Dfilt_nonSOZ.GuoZiqi{1, 16},2),'Color',[0.874509803921569	0.337254901960784	0.282352941176471],'LineWidth',3)
set(gca,'XLim',[0 402])
% plot R
subplot(3,1,3)
plot(rho_SOZ.GuiHaifeng{20})

stereotype_origin = HFOstereo_nonSOZ.GuoZiqi{16, 8};
stereotype_dfilt = Dfilt_nonSOZ.GuoZiqi{1, 16};
save('stereononSOZ_plt.mat','stereotype_origin','stereotype_dfilt')

for i = 1 : length(Dfilt_SOZ.WangXiaoqian)
    if isempty(Dfilt_SOZ.WangXiaoqian{i})~=1
        figure
        plot(Dfilt_SOZ.WangXiaoqian{i},'Color',[0.705882352941177	0.749019607843137	0.756862745098039])
        hold on
        plot(mean(Dfilt_SOZ.WangXiaoqian{i},2),'Color',[0.874509803921569	0.337254901960784	0.282352941176471],'LineWidth',3)
        set(gca,'XLim',[0 402])
    end
end

for i = 1 : length(Dfilt_nonSOZ.WangXiaoqian)
    if isempty(Dfilt_nonSOZ.WangXiaoqian{i})~=1
        figure
        plot(Dfilt_nonSOZ.WangXiaoqian{i},'Color',[0.705882352941177	0.749019607843137	0.756862745098039])
        hold on
        plot(mean(Dfilt_nonSOZ.WangXiaoqian{i},2),'Color',[0.874509803921569	0.337254901960784	0.282352941176471],'LineWidth',3)
        set(gca,'XLim',[0 402])
    end
end