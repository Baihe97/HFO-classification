%% set path & load data
clear
DataPath = 'C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\rawHFOResults';
ToolPath = 'C:\Users\LiZilin\Desktop\PACTools-develop';
EEGPath = 'D:\Matlab\tool\eeglab2021.1';
OutputPath = 'C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data';
addpath(genpath(DataPath))
addpath(genpath(ToolPath))
addpath(genpath(EEGPath))
rmpath(genpath('D:\Matlab\tool\eeglab2021.1\plugins\Biosig3.7.9'))

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\rawHFOResults')
load('ContactsFinal.mat')
load('LabelName.mat')
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data')
load('SOZLabel.mat')
load('EEGstructure.mat')
PT = textread('PTlist.txt','%s');

cd(DataPath)
FileRaw = dir('*.mat');
%% calculate PAC
% nonSOZ channel
for j = 1 : length(PT) % patient ID
    % awake 1
    load(FileRaw(4*j-3).name)
    % col1: channel name, col2: raw data, col3: awake1, col4: awake2, col5:sleep1, col6: sleep2
    HFOpac_nonSOZ = cell(length(RawResults.RawHFO),6);
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOpac_nonSOZ{i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6 % Programming 1st law
                 HFOpac_nonSOZ{i,2} = RawResults.RawHFO{i};
                % hanning window
                w = hann(1201);
                PathHFO = [];
                for k = 1 : size(RawResults.RawHFO{i},1)
                    PathHFO = [PathHFO;w.*(RawResults.RawHFO{i}(k,:))'];
                end
                % establish EEG structure
                EEG.data = reshape(PathHFO',[numel(PathHFO),1])';
                EEG.srate = 2000;
                EEG.times = 0:0.0005:(numel(EEG.data) - 1)/2000;
                EEG.pnts = length(PathHFO);
                %��ʼ��PAC���
                EEG.etc = [];
                %����PAC             
                [EEG,com] = pop_pac(EEG,'channels',[1 35],[50 500],1,1,'method','mvlmi','nfreqs1',35,'nfreqs2',45);
                %����MI����    
                 HFOpac_nonSOZ{i,3} = EEG.etc.eegpac.mvlmi.pacval; 
            end
        end
    end
    % awake 2
    load(FileRaw(4*j-2).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOpac_nonSOZ{i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6
                 HFOpac_nonSOZ{i,2} = RawResults.RawHFO{i};
                % hanning window
                w = hann(1201);
                PathHFO = [];
                for k = 1 : size(RawResults.RawHFO{i},1)
                    PathHFO = [PathHFO;w.*(RawResults.RawHFO{i}(k,:))'];
                end
                % establish EEG structure
                EEG.data = reshape(PathHFO',[numel(PathHFO),1])';
                EEG.srate = 2000;
                EEG.times = 0:0.0005:(numel(EEG.data) - 1)/2000;
                EEG.pnts = length(PathHFO);
                %��ʼ��PAC���
                EEG.etc = [];
                %����PAC
                %n < 6����
                [EEG,com] = pop_pac(EEG,'channels',[1 35],[50 500],1,1,'method','mvlmi','nfreqs1',35,'nfreqs2',45);
                %����MI����    
                 HFOpac_nonSOZ{i,4} = EEG.etc.eegpac.mvlmi.pacval; 
            end
        end
    end
    % sleep 1
    load(FileRaw(4*j-1).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOpac_nonSOZ{i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6
                 HFOpac_nonSOZ{i,2} = RawResults.RawHFO{i};
                % hanning window
                w = hann(1201);
                PathHFO = [];
                for k = 1 : size(RawResults.RawHFO{i},1)
                    PathHFO = [PathHFO;w.*(RawResults.RawHFO{i}(k,:))'];
                end
                % establish EEG structure
                EEG.data = reshape(PathHFO',[numel(PathHFO),1])';
                EEG.srate = 2000;
                EEG.times = 0:0.0005:(numel(EEG.data) - 1)/2000;
                EEG.pnts = length(PathHFO);
                %��ʼ��PAC���
                EEG.etc = [];
                %����PAC
                %n < 6����
                [EEG,com] = pop_pac(EEG,'channels',[1 35],[50 500],1,1,'method','mvlmi','nfreqs1',35,'nfreqs2',45);
                %����MI����    
                 HFOpac_nonSOZ{i,5} = EEG.etc.eegpac.mvlmi.pacval; 
            end
        end
    end
    % sleep 2
    load(FileRaw(4*j).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOpac_nonSOZ{i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6
                 HFOpac_nonSOZ{i,2} = RawResults.RawHFO{i};
                % hanning window
                w = hann(1201);
                PathHFO = [];
                for k = 1 : size(RawResults.RawHFO{i},1)
                    PathHFO = [PathHFO;w.*(RawResults.RawHFO{i}(k,:))'];
                end
                % establish EEG structure
                EEG.data = reshape(PathHFO',[numel(PathHFO),1])';
                EEG.srate = 2000;
                EEG.times = 0:0.0005:(numel(EEG.data) - 1)/2000;
                EEG.pnts = length(PathHFO);
                %��ʼ��PAC���
                EEG.etc = [];
                %����PAC
                %n < 6����
                [EEG,com] = pop_pac(EEG,'channels',[1 35],[50 500],1,1,'method','mvlmi','nfreqs1',35,'nfreqs2',45);
                %����MI����    
                 HFOpac_nonSOZ{i,6} = EEG.etc.eegpac.mvlmi.pacval; 
            end
        end
    end
    % save individual data
    cd(OutputPath)
    save([num2str(j),'_',PT{j},'_','HFOpac_nonSOZ.mat'],'HFOpac_nonSOZ')
end

% SOZ channel
for j = 1 : length(PT) % patient ID
    % awake 1
    load(FileRaw(4*j-3).name)
    % col1: channel name, col2: raw data, col3: awake1, col4: awake2, col5:sleep1, col6: sleep2
    HFOpac_SOZ = cell(length(RawResults.RawHFO),6);
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOpac_SOZ{i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6
                 HFOpac_SOZ{i,2} = RawResults.RawHFO{i};
                % hanning window
                w = hann(1201);
                PathHFO = [];
                for k = 1 : size(RawResults.RawHFO{i},1)
                    PathHFO = [PathHFO;w.*(RawResults.RawHFO{i}(k,:))'];
                end
                % establish EEG structure
                EEG.data = reshape(PathHFO',[numel(PathHFO),1])';
                EEG.srate = 2000;
                EEG.times = 0:0.0005:(numel(EEG.data) - 1)/2000;
                EEG.pnts = length(PathHFO);
                %��ʼ��PAC���
                EEG.etc = [];
                %����PAC
                %n < 6����
                [EEG,com] = pop_pac(EEG,'channels',[1 35],[50 500],1,1,'method','mvlmi','nfreqs1',35,'nfreqs2',45);
                %����MI����    
                 HFOpac_SOZ{i,3} = EEG.etc.eegpac.mvlmi.pacval; 
            end
        end
    end
    % awake 2
    load(FileRaw(4*j-2).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOpac_SOZ{i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6
                 HFOpac_SOZ{i,2} = RawResults.RawHFO{i};
                % hanning window
                w = hann(1201);
                PathHFO = [];
                for k = 1 : size(RawResults.RawHFO{i},1)
                    PathHFO = [PathHFO;w.*(RawResults.RawHFO{i}(k,:))'];
                end
                % establish EEG structure
                EEG.data = reshape(PathHFO',[numel(PathHFO),1])';
                EEG.srate = 2000;
                EEG.times = 0:0.0005:(numel(EEG.data) - 1)/2000;
                EEG.pnts = length(PathHFO);
                %��ʼ��PAC���
                EEG.etc = [];
                %����PAC
                %n < 6����
                [EEG,com] = pop_pac(EEG,'channels',[1 35],[50 500],1,1,'method','mvlmi','nfreqs1',35,'nfreqs2',45);
                %����MI����    
                 HFOpac_SOZ{i,4} = EEG.etc.eegpac.mvlmi.pacval; 
            end
        end
    end
    % sleep 1
    load(FileRaw(4*j-1).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOpac_SOZ{i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6
                 HFOpac_SOZ{i,2} = RawResults.RawHFO{i};
                % hanning window
                w = hann(1201);
                PathHFO = [];
                for k = 1 : size(RawResults.RawHFO{i},1)
                    PathHFO = [PathHFO;w.*(RawResults.RawHFO{i}(k,:))'];
                end
                % establish EEG structure
                EEG.data = reshape(PathHFO',[numel(PathHFO),1])';
                EEG.srate = 2000;
                EEG.times = 0:0.0005:(numel(EEG.data) - 1)/2000;
                EEG.pnts = length(PathHFO);
                %��ʼ��PAC���
                EEG.etc = [];
                %����PAC
                %n < 6����
                [EEG,com] = pop_pac(EEG,'channels',[1 35],[50 500],1,1,'method','mvlmi','nfreqs1',35,'nfreqs2',45);
                %����MI����    
                 HFOpac_SOZ{i,5} = EEG.etc.eegpac.mvlmi.pacval; 
            end
        end
    end
    % sleep 2
    load(FileRaw(4*j).name)
    for i = 1 : length(RawResults.RawHFO)
        Label = LabelName.(PT{j}){i};
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1
            HFOpac_SOZ{i,1} = Label;
            if size(RawResults.RawHFO{i},1) >= 6
                 HFOpac_SOZ{i,2} = RawResults.RawHFO{i};
                % hanning window
                w = hann(1201);
                PathHFO = [];
                for k = 1 : size(RawResults.RawHFO{i},1)
                    PathHFO = [PathHFO;w.*(RawResults.RawHFO{i}(k,:))'];
                end
                % establish EEG structure
                EEG.data = reshape(PathHFO',[numel(PathHFO),1])';
                EEG.srate = 2000;
                EEG.times = 0:0.0005:(numel(EEG.data) - 1)/2000;
                EEG.pnts = length(PathHFO);
                %��ʼ��PAC���
                EEG.etc = [];
                %����PAC
                %n < 6����
                [EEG,com] = pop_pac(EEG,'channels',[1 35],[50 500],1,1,'method','mvlmi','nfreqs1',35,'nfreqs2',45);
                %����MI����    
                 HFOpac_SOZ{i,6} = EEG.etc.eegpac.mvlmi.pacval; 
            end
        end
    end
    % save individual data
    cd(OutputPath)
    save([num2str(j),'_',PT{j},'_','HFOpac_SOZ.mat'],'HFOpac_SOZ')
end

%% settle data
% nonSOZ
ResultsPath = 'C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\PACresults';
addpath(genpath(ResultsPath))
FileResults_nonSOZ = dir('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\PACresults\nonSOZ');
FileResults_nonSOZ = FileResults_nonSOZ(3:end,:);

HFO_pac_nonSOZWhole = cell(0);
for i = 1 : length(PT)
    load(FileResults_nonSOZ(i).name)
    for j = 1 : length(HFOpac_nonSOZ)
        if isempty(HFOpac_nonSOZ{j,1}) ~= 1
            HFO_pac_nonSOZWhole = [HFO_pac_nonSOZWhole;HFOpac_nonSOZ(j,:)];
        end
    end
end

HFO_pac_nonSOZWholeTemp = cell(size(HFO_pac_nonSOZWhole,1),3);
HFO_pac_nonSOZWholeTemp(:,1) = HFO_pac_nonSOZWhole(:,1);
for k = 1 : size(HFO_pac_nonSOZWhole,1)
    % col2: awake data
    indicator = isempty(HFO_pac_nonSOZWhole{k,3}) + isempty(HFO_pac_nonSOZWhole{k,4});
    switch indicator
        case 2
            HFO_pac_nonSOZWholeTemp{k,2} = [];
        case 0
            HFO_pac_nonSOZWholeTemp{k,2} = (HFO_pac_nonSOZWhole{k,3} + HFO_pac_nonSOZWhole{k,4})/2;
        case 1
            if isempty(HFO_pac_nonSOZWhole{k,3}) == 1
                HFO_pac_nonSOZWholeTemp{k,2} = HFO_pac_nonSOZWhole{k,4};
            else 
                HFO_pac_nonSOZWholeTemp{k,2} = HFO_pac_nonSOZWhole{k,3};
            end
    end
    % col3: sleep data
    indicator = isempty(HFO_pac_nonSOZWhole{k,5}) + isempty(HFO_pac_nonSOZWhole{k,6});
    switch indicator
        case 2
            HFO_pac_nonSOZWholeTemp{k,3} = [];
        case 0
            HFO_pac_nonSOZWholeTemp{k,3} =(HFO_pac_nonSOZWhole{k,5} + HFO_pac_nonSOZWhole{k,6})/2;
        case 1
            if isempty(HFO_pac_nonSOZWhole{k,5}) == 1
                HFO_pac_nonSOZWholeTemp{k,3} = HFO_pac_nonSOZWhole{k,6};
            else 
                HFO_pac_nonSOZWholeTemp{k,3} = HFO_pac_nonSOZWhole{k,5};
            end
    end
end

HFO_pac_nonSOZWholeFinal = HFO_pac_nonSOZWholeTemp;
for a = 1 : size(HFO_pac_nonSOZWholeFinal,1)
    for b = 2 : size(HFO_pac_nonSOZWholeFinal,2)
        if isempty(HFO_pac_nonSOZWholeFinal{a,b}) ~= 1
            HFO_pac_nonSOZWholeFinal{a,b} = HFO_pac_nonSOZWholeFinal{a,b}';
            HFO_pac_nonSOZWholeFinal{a,b} = sum(sum(HFO_pac_nonSOZWholeFinal{a,b}(30:45,3:10)));
            HFO_pac_nonSOZWholeFinal{a,b} = HFO_pac_nonSOZWholeFinal{a,b}/128;
        end
    end
end

% SOZ
FileResults_SOZ = dir('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\PACresults\SOZ');
FileResults_SOZ = FileResults_SOZ(3:end,:);

HFO_pac_SOZWhole = cell(0);
for i = 1 : length(PT)
    load(FileResults_SOZ(i).name)
    for j = 1 : length(HFOpac_SOZ)
        if isempty(HFOpac_SOZ{j,1}) ~= 1
            HFO_pac_SOZWhole = [HFO_pac_SOZWhole;HFOpac_SOZ(j,:)];
        end
    end
end

HFO_pac_SOZWholeTemp = cell(size(HFO_pac_SOZWhole,1),3);
HFO_pac_SOZWholeTemp(:,1) = HFO_pac_SOZWhole(:,1);
for k = 1 : size(HFO_pac_SOZWhole,1)
    % col2: awake data
    indicator = isempty(HFO_pac_SOZWhole{k,3}) + isempty(HFO_pac_SOZWhole{k,4});
    switch indicator
        case 2
            HFO_pac_SOZWholeTemp{k,2} = [];
        case 0
            HFO_pac_SOZWholeTemp{k,2} = (HFO_pac_SOZWhole{k,3} + HFO_pac_SOZWhole{k,4})/2;
        case 1
            if isempty(HFO_pac_SOZWhole{k,3}) == 1
                HFO_pac_SOZWholeTemp{k,2} = HFO_pac_SOZWhole{k,4};
            else 
                HFO_pac_SOZWholeTemp{k,2} = HFO_pac_SOZWhole{k,3};
            end
    end
    % col3: sleep data
    indicator = isempty(HFO_pac_SOZWhole{k,5}) + isempty(HFO_pac_SOZWhole{k,6});
    switch indicator
        case 2
            HFO_pac_SOZWholeTemp{k,3} = [];
        case 0
            HFO_pac_SOZWholeTemp{k,3} =(HFO_pac_SOZWhole{k,5} + HFO_pac_SOZWhole{k,6})/2;
        case 1
            if isempty(HFO_pac_SOZWhole{k,5}) == 1
                HFO_pac_SOZWholeTemp{k,3} = HFO_pac_SOZWhole{k,6};
            else 
                HFO_pac_SOZWholeTemp{k,3} = HFO_pac_SOZWhole{k,5};
            end
    end
end

HFO_pac_SOZWholeFinal = HFO_pac_SOZWholeTemp;
for a = 1 : size(HFO_pac_SOZWholeFinal,1)
    for b = 2 : size(HFO_pac_SOZWholeFinal,2)
        if isempty(HFO_pac_SOZWholeFinal{a,b}) ~= 1
            HFO_pac_SOZWholeFinal{a,b} = HFO_pac_SOZWholeFinal{a,b}';
            HFO_pac_SOZWholeFinal{a,b} = sum(sum(HFO_pac_SOZWholeFinal{a,b}(30:45,3:10)));
            HFO_pac_SOZWholeFinal{a,b} = HFO_pac_SOZWholeFinal{a,b}/128;
        end
    end
end

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\awake_sleep_data')
save('PAC_SOZ.mat','HFO_pac_SOZWholeFinal')
save('PAC_nonSOZ.mat','HFO_pac_nonSOZWholeFinal')
%% figure
figure
imagesc(pac_nonSOZavgInd')
axis xy
axis square
colorbar
caxis([-2,5])
set(gca,'YTickLabel',{'95','140','185','230','275','320','365','410','455','500'})

figure
imagesc(final)
axis xy
axis square
colorbar
% caxis([-2,3])
set(gca,'YTickLabel',{'95','140','185','230','275','320','365','410','455','500'})

PAC_radarplt_SOZ = HFOpac_SOZ{57, 2};
PAC_radarplt_nonSOZ = HFOpac_nonSOZ{59, 2};

% concatenated HFO
addpath('C:\Users\LiZilin\Desktop\cdcol')
load cdcol.mat
% SOZ
figure
t = 0:1/2000:1201*20/2000-1/2000;
plot(t,reshape(PAC_SOZ(1:20,:)',[1,1201*20]),'Color',cdcol.black)
axis tight
box off
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0.1 0.1 0.7 0.4]);
set(gca,'fontsize', 20)
print('PAC_SOZ_20trials','-dtiff','-r600')
close


figure
t = 0:1/2000:601/2000-1/2000;
sig = reshape(PAC_SOZ(2,:)',[1,1201]);
plot(t,sig(301:901),'Color','r','LineWidth',2)
axis tight
axis square
box off
axis off
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0.1 0.1 0.4 0.4]);
set(gca,'fontsize', 20)
print('PAC_SOZ_2nd_trials','-dtiff','-r600')
close

% nonSOZ
figure
t = 0:1/2000:1201*20/2000-1/2000;
plot(t,reshape(PAC_radarplt_nonSOZ(23:42,:)',[1,1201*20]),'Color',cdcol.black)
axis tight
box off
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0.1 0.1 0.7 0.4]);
set(gca,'fontsize', 20)
print('PAC_SOZ_20trials','-dtiff','-r600')
close

% nonSOZ
figure
t = 0:1/2000:1201*77/2000-1/2000;
plot(t,reshape(PAC_radarplt_nonSOZ(:,:)',[1,1201*77]),'Color',cdcol.black)
axis tight
box off
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0.1 0.1 0.7 0.4]);
set(gca,'fontsize', 20)
print('PAC_SOZ_20trials','-dtiff','-r600')
close


figure
t = 0:1/2000:1201*20/2000-1/2000;
plot(t,reshape(PAC_radarplt_nonSOZ(6:25,:)',[1,1201*20]),'Color',cdcol.black)
axis tight
box off
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0.1 0.1 0.7 0.4]);
set(gca,'fontsize', 20)
print('PAC_nonSOZ_20trials','-dtiff','-r600')
close

figure
t = 0:1/2000:601/2000-1/2000;
sig = reshape(PAC_radarplt_nonSOZ(12,:)',[1,1201]);
plot(t,sig(301:901),'Color',cdcol.ultramarine,'LineWidth',2)
axis tight
axis square
box off
axis off
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0.1 0.1 0.4 0.4]);
set(gca,'fontsize', 20)
print('PAC_nonSOZ_12th_trials','-dtiff','-r600')
close





