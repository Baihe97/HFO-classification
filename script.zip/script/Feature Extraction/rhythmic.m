%% set path & load data
ToolPath = 'C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\HFOclasses';
DataPath = 'C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\rawHFOResults2';
addpath(genpath(ToolPath))
addpath(genpath(DataPath))

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\rawHFOResults')
load('ContactsFinal.mat')
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data')
load('SOZLabel.mat')
PT = textread('PTlist.txt','%s');

cd(DataPath)
FileRaw = dir('*.mat');

%% calculate HFO peak-to-peak interval
% nonSOZ channel
for j = 1: length(PT)
    % awake 1
    load(FileRaw(4*j-3).name)
    HFOinterval_nonSOZ.(PT{j}) = cell(length(HFO.iEEGRaw.channels),17);
    for i = 1 : length(HFO.iEEGRaw.channels)
        Label = [PT{j},'_',HFO.iEEGRaw.channels(i).label];
            if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1
                HFOinterval_nonSOZ.(PT{j}){i,1} = Label;
                if size(HFO.CandidateHFOsFinalEventsTimeStamps{i},1) >= 6
                    HFOinterval_nonSOZ.(PT{j}){i,2}= diff(HFO.CandidateHFOsFinalEventsTimeStamps{i}(:,2));                     
                end
            end
    end
    % awake 2
    load(FileRaw(4*j-2).name)
    for i = 1 : length(HFO.iEEGRaw.channels)
        Label = [PT{j},'_',HFO.iEEGRaw.channels(i).label];
            if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1 
                if size(HFO.CandidateHFOsFinalEventsTimeStamps{i},1) >= 6
                    HFOinterval_nonSOZ.(PT{j}){i,6}= diff(HFO.CandidateHFOsFinalEventsTimeStamps{i}(:,2));
                    
                end
            end        
    end
    % sleep 1
    load(FileRaw(4*j-1).name)
    for i = 1 : length(HFO.iEEGRaw.channels)
        Label = [PT{j},'_',HFO.iEEGRaw.channels(i).label];
            if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1 
                if size(HFO.CandidateHFOsFinalEventsTimeStamps{i},1) >= 6
                    HFOinterval_nonSOZ.(PT{j}){i,10}= diff(HFO.CandidateHFOsFinalEventsTimeStamps{i}(:,2));
                    
                end
            end
    end
    % sleep 2
    load(FileRaw(4*j).name)
    for i = 1 : length(HFO.iEEGRaw.channels)
        Label = [PT{j},'_',HFO.iEEGRaw.channels(i).label];
            if ismember(Label,SOZ_HFOLabel) ~= 1 && ismember(Label,ContactsFinal.Name) == 1 
                if size(HFO.CandidateHFOsFinalEventsTimeStamps{i},1) >= 6
                    HFOinterval_nonSOZ.(PT{j}){i,14}= diff(HFO.CandidateHFOsFinalEventsTimeStamps{i}(:,2));
                    
                end
            end       
    end
end

% SOZ channel
for j = 1: length(PT)
    
    load(FileRaw(4*j-3).name)
    HFOinterval_SOZ.(PT{j}) = cell(length(HFO.iEEGRaw.channels),17);
    for i = 1 : length(HFO.iEEGRaw.channels)
        Label = [PT{j},'_',HFO.iEEGRaw.channels(i).label];
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1   
            HFOinterval_SOZ.(PT{j}){i,1} = Label;
            if size(HFO.CandidateHFOsFinalEventsTimeStamps{i},1) >= 6
                HFOinterval_SOZ.(PT{j}){i,2} = diff(HFO.CandidateHFOsFinalEventsTimeStamps{i}(:,2)) ;
                
            end           
        end
    end
    load(FileRaw(4*j-2).name)
    for i = 1 : length(HFO.iEEGRaw.channels)
        Label = [PT{j},'_',HFO.iEEGRaw.channels(i).label];
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1            
            if size(HFO.CandidateHFOsFinalEventsTimeStamps{i},1) >= 6
                HFOinterval_SOZ.(PT{j}){i,6}= diff(HFO.CandidateHFOsFinalEventsTimeStamps{i}(:,2)) ;
               
            end           
        end
    end
    load(FileRaw(4*j-1).name)
    for i = 1 : length(HFO.iEEGRaw.channels)
        Label = [PT{j},'_',HFO.iEEGRaw.channels(i).label];
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1            
            if size(HFO.CandidateHFOsFinalEventsTimeStamps{i},1) >= 6
                HFOinterval_SOZ.(PT{j}){i,10}= diff(HFO.CandidateHFOsFinalEventsTimeStamps{i}(:,2)) ;
                
            end           
        end
    end
    load(FileRaw(4*j).name)
    for i = 1 : length(HFO.iEEGRaw.channels)
        Label = [PT{j},'_',HFO.iEEGRaw.channels(i).label];
        if ismember(Label,SOZ_HFOLabel) == 1 && ismember(Label,ContactsFinal.Name) == 1            
            if size(HFO.CandidateHFOsFinalEventsTimeStamps{i},1) >= 6
                HFOinterval_SOZ.(PT{j}){i,14}= diff(HFO.CandidateHFOsFinalEventsTimeStamps{i}(:,2)) ;
                
            end           
        end
    end
end


%% SD & skewness & kurtosis

for i = nonFCD_ID
    % nonSOZ
    for j = 1 : length(HFOinterval_nonSOZ.(PT{i}))
        if length(HFOinterval_nonSOZ.(PT{i}){j,2}) >= 6
           % col3: SD
           HFOinterval_nonSOZ.(PT{i}){j,3} = std(HFOinterval_nonSOZ.(PT{i}){j,2}); 
           % col4: skewness 
           HFOinterval_nonSOZ.(PT{i}){j,4} = skewness(HFOinterval_nonSOZ.(PT{i}){j,2});
           % col5: kurtosis
           HFOinterval_nonSOZ.(PT{i}){j,5} = kurtosis(HFOinterval_nonSOZ.(PT{i}){j,2});
        end
        if length(HFOinterval_nonSOZ.(PT{i}){j,6}) >= 6
           % col7: SD
           HFOinterval_nonSOZ.(PT{i}){j,7} = std(HFOinterval_nonSOZ.(PT{i}){j,6});
           % col8: skewness 
           HFOinterval_nonSOZ.(PT{i}){j,8} = skewness(HFOinterval_nonSOZ.(PT{i}){j,6});
           % col9: kurtosis
           HFOinterval_nonSOZ.(PT{i}){j,9} = kurtosis(HFOinterval_nonSOZ.(PT{i}){j,6});
        end
        if length(HFOinterval_nonSOZ.(PT{i}){j,10}) >= 6
           % col11: SD
           HFOinterval_nonSOZ.(PT{i}){j,11} = std(HFOinterval_nonSOZ.(PT{i}){j,10});
           % col12: skewness 
           HFOinterval_nonSOZ.(PT{i}){j,12} = skewness(HFOinterval_nonSOZ.(PT{i}){j,10});
           % col13: kurtosis
           HFOinterval_nonSOZ.(PT{i}){j,13} = kurtosis(HFOinterval_nonSOZ.(PT{i}){j,10});
        end
        if length(HFOinterval_nonSOZ.(PT{i}){j,14}) >= 6
           % col15: SD
           HFOinterval_nonSOZ.(PT{i}){j,15} = std(HFOinterval_nonSOZ.(PT{i}){j,14});
           % col16: skewness 
           HFOinterval_nonSOZ.(PT{i}){j,16} = skewness(HFOinterval_nonSOZ.(PT{i}){j,14});
           % col17: kurtosis
           HFOinterval_nonSOZ.(PT{i}){j,17} = kurtosis(HFOinterval_nonSOZ.(PT{i}){j,14});
        end
        
        % SOZ
        if length(HFOinterval_SOZ.(PT{i}){j,2}) >= 6
           % col3: SD
           HFOinterval_SOZ.(PT{i}){j,3} = std(HFOinterval_SOZ.(PT{i}){j,2}); 
           % col4: skewness 
           HFOinterval_SOZ.(PT{i}){j,4} = skewness(HFOinterval_SOZ.(PT{i}){j,2});
           % col5: kurtosis
           HFOinterval_SOZ.(PT{i}){j,5} = kurtosis(HFOinterval_SOZ.(PT{i}){j,2});
        end
        if length(HFOinterval_SOZ.(PT{i}){j,6}) >= 6
           % col7: SD
           HFOinterval_SOZ.(PT{i}){j,7} = std(HFOinterval_SOZ.(PT{i}){j,6});
           % col8: skewness 
           HFOinterval_SOZ.(PT{i}){j,8} = skewness(HFOinterval_SOZ.(PT{i}){j,6});
           % col9: kurtosis
           HFOinterval_SOZ.(PT{i}){j,9} = kurtosis(HFOinterval_SOZ.(PT{i}){j,6});
        end
        if length(HFOinterval_SOZ.(PT{i}){j,10}) >= 6
           % col11: SD
           HFOinterval_SOZ.(PT{i}){j,11} = std(HFOinterval_SOZ.(PT{i}){j,10});
           % col12: skewness 
           HFOinterval_SOZ.(PT{i}){j,12} = skewness(HFOinterval_SOZ.(PT{i}){j,10});
           % col13: kurtosis
           HFOinterval_SOZ.(PT{i}){j,13} = kurtosis(HFOinterval_SOZ.(PT{i}){j,10});
        end
        if length(HFOinterval_SOZ.(PT{i}){j,14}) >= 6
           % col15: SD
           HFOinterval_SOZ.(PT{i}){j,15} = std(HFOinterval_SOZ.(PT{i}){j,14});
           % col16: skewness 
           HFOinterval_SOZ.(PT{i}){j,16} = skewness(HFOinterval_SOZ.(PT{i}){j,14});
           % col17: kurtosis
           HFOinterval_SOZ.(PT{i}){j,17} = kurtosis(HFOinterval_SOZ.(PT{i}){j,14});
        end
    end
end

%% settle data

% SOZ
HFO_interval_SOZWhole =[];
for i = nonFCD_ID
    for j = 1 : size(HFOinterval_SOZ.(PT{i}),1)
        if isempty(HFOinterval_SOZ.(PT{i}){j, 1}) ~= 1
            HFO_interval_SOZWhole =[HFO_interval_SOZWhole;HFOinterval_SOZ.(PT{i})(j, :)];
        end
    end
end
HFO_interval_SOZWholeFinal = cell(size(HFO_interval_SOZWhole,1),7);
HFO_interval_SOZWholeFinal(:,1) = HFO_interval_SOZWhole(:,1);
for k = 1 : size(HFO_interval_SOZWhole,1)
    % col2: awake data_SD
    indicator = isempty(HFO_interval_SOZWhole{k,3}) + isempty(HFO_interval_SOZWhole{k,7});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,2} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,2} = mean([HFO_interval_SOZWhole{k,3},HFO_interval_SOZWhole{k,7}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,3}) == 1
                HFO_interval_SOZWholeFinal{k,2} = HFO_interval_SOZWhole{k,7};
            else 
                HFO_interval_SOZWholeFinal{k,2} = HFO_interval_SOZWhole{k,3};
            end
    end
    % col3: awake data_skewness
    indicator = isempty(HFO_interval_SOZWhole{k,4}) + isempty(HFO_interval_SOZWhole{k,8});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,3} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,3} = mean([HFO_interval_SOZWhole{k,4},HFO_interval_SOZWhole{k,8}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,4}) == 1
                HFO_interval_SOZWholeFinal{k,3} = HFO_interval_SOZWhole{k,8};
            else 
                HFO_interval_SOZWholeFinal{k,3} = HFO_interval_SOZWhole{k,4};
            end
    end
    % col4: awake data_kurtosis
    indicator = isempty(HFO_interval_SOZWhole{k,5}) + isempty(HFO_interval_SOZWhole{k,9});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,4} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,4} = mean([HFO_interval_SOZWhole{k,5},HFO_interval_SOZWhole{k,9}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,5}) == 1
                HFO_interval_SOZWholeFinal{k,4} = HFO_interval_SOZWhole{k,9};
            else 
                HFO_interval_SOZWholeFinal{k,4} = HFO_interval_SOZWhole{k,5};
            end
    end
   % col5: sleep data_SD
    indicator = isempty(HFO_interval_SOZWhole{k,11}) + isempty(HFO_interval_SOZWhole{k,15});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,5} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,5} = mean([HFO_interval_SOZWhole{k,11},HFO_interval_SOZWhole{k,15}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,11}) == 1
                HFO_interval_SOZWholeFinal{k,5} = HFO_interval_SOZWhole{k,15};
            else 
                HFO_interval_SOZWholeFinal{k,5} = HFO_interval_SOZWhole{k,11};
            end
    end
    % col6: sleep data_skewness
    indicator = isempty(HFO_interval_SOZWhole{k,12}) + isempty(HFO_interval_SOZWhole{k,16});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,6} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,6} = mean([HFO_interval_SOZWhole{k,12},HFO_interval_SOZWhole{k,16}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,12}) == 1
                HFO_interval_SOZWholeFinal{k,6} = HFO_interval_SOZWhole{k,16};
            else 
                HFO_interval_SOZWholeFinal{k,6} = HFO_interval_SOZWhole{k,12};
            end
    end
    % col7: sleep data_kurtosis
    indicator = isempty(HFO_interval_SOZWhole{k,13}) + isempty(HFO_interval_SOZWhole{k,17});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,7} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,7} = mean([HFO_interval_SOZWhole{k,13},HFO_interval_SOZWhole{k,17}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,13}) == 1
                HFO_interval_SOZWholeFinal{k,7} = HFO_interval_SOZWhole{k,17};
            else 
                HFO_interval_SOZWholeFinal{k,7} = HFO_interval_SOZWhole{k,13};
            end
    end
end

% nonSOZ
HFO_interval_nonSOZWhole =[];
for i = nonFCD_ID
    for j = 1 : size(HFOinterval_nonSOZ.(PT{i}),1)
        if isempty(HFOinterval_nonSOZ.(PT{i}){j, 1}) ~= 1
            HFO_interval_nonSOZWhole =[HFO_interval_nonSOZWhole;HFOinterval_nonSOZ.(PT{i})(j, :)];
        end
    end
end
HFO_interval_nonSOZWholeFinal = cell(size(HFO_interval_nonSOZWhole,1),7);
HFO_interval_nonSOZWholeFinal(:,1) = HFO_interval_nonSOZWhole(:,1);
for k = 1 : size(HFO_interval_nonSOZWhole,1)
    % col2: awake data_SD
    indicator = isempty(HFO_interval_nonSOZWhole{k,3}) + isempty(HFO_interval_nonSOZWhole{k,7});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,2} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,2} = mean([HFO_interval_nonSOZWhole{k,3},HFO_interval_nonSOZWhole{k,7}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,3}) == 1
                HFO_interval_nonSOZWholeFinal{k,2} = HFO_interval_nonSOZWhole{k,7};
            else 
                HFO_interval_nonSOZWholeFinal{k,2} = HFO_interval_nonSOZWhole{k,3};
            end
    end
    % col3: awake data_skewness
    indicator = isempty(HFO_interval_nonSOZWhole{k,4}) + isempty(HFO_interval_nonSOZWhole{k,8});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,3} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,3} = mean([HFO_interval_nonSOZWhole{k,4},HFO_interval_nonSOZWhole{k,8}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,4}) == 1
                HFO_interval_nonSOZWholeFinal{k,3} = HFO_interval_nonSOZWhole{k,8};
            else 
                HFO_interval_nonSOZWholeFinal{k,3} = HFO_interval_nonSOZWhole{k,4};
            end
    end
    % col4: awake data_kurtosis
    indicator = isempty(HFO_interval_nonSOZWhole{k,5}) + isempty(HFO_interval_nonSOZWhole{k,9});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,4} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,4} = mean([HFO_interval_nonSOZWhole{k,5},HFO_interval_nonSOZWhole{k,9}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,5}) == 1
                HFO_interval_nonSOZWholeFinal{k,4} = HFO_interval_nonSOZWhole{k,9};
            else 
                HFO_interval_nonSOZWholeFinal{k,4} = HFO_interval_nonSOZWhole{k,5};
            end
    end
   % col5: sleep data_SD
    indicator = isempty(HFO_interval_nonSOZWhole{k,11}) + isempty(HFO_interval_nonSOZWhole{k,15});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,5} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,5} = mean([HFO_interval_nonSOZWhole{k,11},HFO_interval_nonSOZWhole{k,15}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,11}) == 1
                HFO_interval_nonSOZWholeFinal{k,5} = HFO_interval_nonSOZWhole{k,15};
            else 
                HFO_interval_nonSOZWholeFinal{k,5} = HFO_interval_nonSOZWhole{k,11};
            end
    end
    % col6: sleep data_skewness
    indicator = isempty(HFO_interval_nonSOZWhole{k,12}) + isempty(HFO_interval_nonSOZWhole{k,16});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,6} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,6} = mean([HFO_interval_nonSOZWhole{k,12},HFO_interval_nonSOZWhole{k,16}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,12}) == 1
                HFO_interval_nonSOZWholeFinal{k,6} = HFO_interval_nonSOZWhole{k,16};
            else 
                HFO_interval_nonSOZWholeFinal{k,6} = HFO_interval_nonSOZWhole{k,12};
            end
    end
    % col7: sleep data_kurtosis
    indicator = isempty(HFO_interval_nonSOZWhole{k,13}) + isempty(HFO_interval_nonSOZWhole{k,17});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,7} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,7} = mean([HFO_interval_nonSOZWhole{k,13},HFO_interval_nonSOZWhole{k,17}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,13}) == 1
                HFO_interval_nonSOZWholeFinal{k,7} = HFO_interval_nonSOZWhole{k,17};
            else 
                HFO_interval_nonSOZWholeFinal{k,7} = HFO_interval_nonSOZWhole{k,13};
            end
    end
end

% save data
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\awake_sleep_data')
save('rhythmic_SOZ.mat','HFO_interval_SOZWholeFinal')
save('rhythmic_nonSOZ.mat','HFO_interval_nonSOZWholeFinal')

%%

HFOinterval_nonSOZ_whole = [];
for i = 1 : length(PT)
    HFOinterval_nonSOZ_whole = [HFOinterval_nonSOZ_whole;cat(1,HFOinterval_nonSOZ.(PT{i}){:})];
end

HFOinterval_SOZ_whole = [];
for i = 1 : length(PT)
    HFOinterval_SOZ_whole = [HFOinterval_SOZ_whole;cat(1,HFOinterval_SOZ.(PT{i}){:})];
end


wholeInterval_SOZ = [];
wholeInterval_nonSOZ = [];
for i = 1 : length(PT)
    wholeInterval_SOZ = [wholeInterval_SOZ;[cat(1,HFOinterval_SOZ.(PT{i}){:,2});cat(1,HFOinterval_SOZ.(PT{i}){:,6});cat(1,HFOinterval_SOZ.(PT{i}){:,10});cat(1,HFOinterval_SOZ.(PT{i}){:,14})]];
    wholeInterval_nonSOZ = [wholeInterval_nonSOZ;[cat(1,HFOinterval_nonSOZ.(PT{i}){:,2});cat(1,HFOinterval_nonSOZ.(PT{i}){:,6});cat(1,HFOinterval_nonSOZ.(PT{i}){:,10});cat(1,HFOinterval_nonSOZ.(PT{i}){:,14})]];   
end

% normalize the histogram
wholeInterval_SOZ = normalize(wholeInterval_SOZ,'range');
wholeInterval_nonSOZ = normalize(wholeInterval_nonSOZ,'range');

figure
hSOZ = histogram(wholeInterval_SOZ,'BinWidth',0.001);
hold on
hnonSOZ = histogram(wholeInterval_nonSOZ,'BinWidth',0.001,'FaceColor','r');    

SOZcurve = log10(wholeInterval_SOZ);
SOZcurve(isinf(SOZcurve)) = nan;
SOZcurve = fillgaps(SOZcurve);
SOZcurve = smooth(SOZcurve,80);


nonSOZcurve = log10(wholeInterval_nonSOZ);
nonSOZcurve(isinf(nonSOZcurve)) = nan;
nonSOZcurve = fillgaps(nonSOZcurve);
nonSOZcurve = smooth(nonSOZcurve,80);

figure
plot(SOZcurve)
hold on
plot(nonSOZcurve)

for i = 1 : length(PT)
    tempHFOdiffSOZ = [cat(1,HFOinterval_SOZ.(PT{i}){:,2});cat(1,HFOinterval_SOZ.(PT{i}){:,6});cat(1,HFOinterval_SOZ.(PT{i}){:,10});cat(1,HFOinterval_SOZ.(PT{i}){:,14})];
    tempHFOdiffnonSOZ = [cat(1,HFOinterval_nonSOZ.(PT{i}){:,2});cat(1,HFOinterval_nonSOZ.(PT{i}){:,6});cat(1,HFOinterval_nonSOZ.(PT{i}){:,10});cat(1,HFOinterval_nonSOZ.(PT{i}){:,14})];
    tempHFOdiffSOZ = normalize(tempHFOdiffSOZ,'range');
    tempHFOdiffnonSOZ = normalize(tempHFOdiffnonSOZ,'range');
    
    figure
    hSOZ = histogram(tempHFOdiffSOZ,'BinWidth',0.001);
    hold on
    hnonSOZ = histogram(tempHFOdiffnonSOZ,'BinWidth',0.001);
    
    normalizedSOZsub(i,:) = normalize(hSOZ.Values,'range');
    normalizednonSOZsub(i,:) = normalize(hnonSOZ.Values,'range');
    
    close
end

figure
imagesc(normalizedSOZsub)

figure
imagesc(normalizednonSOZsub)


normalizedSOZsubCurve = mean(normalizedSOZsub);
normalizednonSOZsubCurve = mean(normalizednonSOZsub);

SOZcurve = log10(normalizedSOZsubCurve);
SOZcurve(isinf(SOZcurve)) = nan;
SOZcurve = fillgaps(SOZcurve);
SOZcurve = smooth(SOZcurve,80);


nonSOZcurve = log10(normalizednonSOZsubCurve);
nonSOZcurve(isinf(nonSOZcurve)) = nan;
nonSOZcurve = fillgaps(nonSOZcurve);
nonSOZcurve = smooth(nonSOZcurve,80);

figure
plot(SOZcurve,'LineWidth',1)
hold on
plot(nonSOZcurve,'LineWidth',1)
legend('SOZ','nonSOZ')

figure
basevalue = -5;
area(nonSOZcurve,basevalue,'FaceColor','r')
hold on
area(SOZcurve,basevalue,'FaceColor','b')

%% settle data for FCD
% SOZ
FCD_id = [1 6 7 8 18 19 23 25 27];
HFO_interval_SOZWhole =[];
for i = FCD_id
    for j = 1 : size(HFOinterval_SOZ.(PT{i}),1)
        if isempty(HFOinterval_SOZ.(PT{i}){j, 1}) ~= 1
            HFO_interval_SOZWhole =[HFO_interval_SOZWhole;HFOinterval_SOZ.(PT{i})(j, :)];
        end
    end
end
HFO_interval_SOZWholeFinal = cell(size(HFO_interval_SOZWhole,1),7);
HFO_interval_SOZWholeFinal(:,1) = HFO_interval_SOZWhole(:,1);
for k = 1 : size(HFO_interval_SOZWhole,1)
    % col2: awake data_SD
    indicator = isempty(HFO_interval_SOZWhole{k,3}) + isempty(HFO_interval_SOZWhole{k,7});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,2} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,2} = mean([HFO_interval_SOZWhole{k,3},HFO_interval_SOZWhole{k,7}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,3}) == 1
                HFO_interval_SOZWholeFinal{k,2} = HFO_interval_SOZWhole{k,7};
            else 
                HFO_interval_SOZWholeFinal{k,2} = HFO_interval_SOZWhole{k,3};
            end
    end
    % col3: awake data_skewness
    indicator = isempty(HFO_interval_SOZWhole{k,4}) + isempty(HFO_interval_SOZWhole{k,8});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,3} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,3} = mean([HFO_interval_SOZWhole{k,4},HFO_interval_SOZWhole{k,8}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,4}) == 1
                HFO_interval_SOZWholeFinal{k,3} = HFO_interval_SOZWhole{k,8};
            else 
                HFO_interval_SOZWholeFinal{k,3} = HFO_interval_SOZWhole{k,4};
            end
    end
    % col4: awake data_kurtosis
    indicator = isempty(HFO_interval_SOZWhole{k,5}) + isempty(HFO_interval_SOZWhole{k,9});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,4} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,4} = mean([HFO_interval_SOZWhole{k,5},HFO_interval_SOZWhole{k,9}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,5}) == 1
                HFO_interval_SOZWholeFinal{k,4} = HFO_interval_SOZWhole{k,9};
            else 
                HFO_interval_SOZWholeFinal{k,4} = HFO_interval_SOZWhole{k,5};
            end
    end
   % col5: sleep data_SD
    indicator = isempty(HFO_interval_SOZWhole{k,11}) + isempty(HFO_interval_SOZWhole{k,15});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,5} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,5} = mean([HFO_interval_SOZWhole{k,11},HFO_interval_SOZWhole{k,15}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,11}) == 1
                HFO_interval_SOZWholeFinal{k,5} = HFO_interval_SOZWhole{k,15};
            else 
                HFO_interval_SOZWholeFinal{k,5} = HFO_interval_SOZWhole{k,11};
            end
    end
    % col6: sleep data_skewness
    indicator = isempty(HFO_interval_SOZWhole{k,12}) + isempty(HFO_interval_SOZWhole{k,16});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,6} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,6} = mean([HFO_interval_SOZWhole{k,12},HFO_interval_SOZWhole{k,16}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,12}) == 1
                HFO_interval_SOZWholeFinal{k,6} = HFO_interval_SOZWhole{k,16};
            else 
                HFO_interval_SOZWholeFinal{k,6} = HFO_interval_SOZWhole{k,12};
            end
    end
    % col7: sleep data_kurtosis
    indicator = isempty(HFO_interval_SOZWhole{k,13}) + isempty(HFO_interval_SOZWhole{k,17});
    switch indicator
        case 2
            HFO_interval_SOZWholeFinal{k,7} = [];
        case 0
            HFO_interval_SOZWholeFinal{k,7} = mean([HFO_interval_SOZWhole{k,13},HFO_interval_SOZWhole{k,17}]);
        case 1
            if isempty(HFO_interval_SOZWhole{k,13}) == 1
                HFO_interval_SOZWholeFinal{k,7} = HFO_interval_SOZWhole{k,17};
            else 
                HFO_interval_SOZWholeFinal{k,7} = HFO_interval_SOZWhole{k,13};
            end
    end
end

% nonSOZ
HFO_interval_nonSOZWhole =[];
for i = FCD_id
    for j = 1 : size(HFOinterval_nonSOZ.(PT{i}),1)
        if isempty(HFOinterval_nonSOZ.(PT{i}){j, 1}) ~= 1
            HFO_interval_nonSOZWhole =[HFO_interval_nonSOZWhole;HFOinterval_nonSOZ.(PT{i})(j, :)];
        end
    end
end
HFO_interval_nonSOZWholeFinal = cell(size(HFO_interval_nonSOZWhole,1),7);
HFO_interval_nonSOZWholeFinal(:,1) = HFO_interval_nonSOZWhole(:,1);
for k = 1 : size(HFO_interval_nonSOZWhole,1)
    % col2: awake data_SD
    indicator = isempty(HFO_interval_nonSOZWhole{k,3}) + isempty(HFO_interval_nonSOZWhole{k,7});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,2} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,2} = mean([HFO_interval_nonSOZWhole{k,3},HFO_interval_nonSOZWhole{k,7}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,3}) == 1
                HFO_interval_nonSOZWholeFinal{k,2} = HFO_interval_nonSOZWhole{k,7};
            else 
                HFO_interval_nonSOZWholeFinal{k,2} = HFO_interval_nonSOZWhole{k,3};
            end
    end
    % col3: awake data_skewness
    indicator = isempty(HFO_interval_nonSOZWhole{k,4}) + isempty(HFO_interval_nonSOZWhole{k,8});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,3} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,3} = mean([HFO_interval_nonSOZWhole{k,4},HFO_interval_nonSOZWhole{k,8}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,4}) == 1
                HFO_interval_nonSOZWholeFinal{k,3} = HFO_interval_nonSOZWhole{k,8};
            else 
                HFO_interval_nonSOZWholeFinal{k,3} = HFO_interval_nonSOZWhole{k,4};
            end
    end
    % col4: awake data_kurtosis
    indicator = isempty(HFO_interval_nonSOZWhole{k,5}) + isempty(HFO_interval_nonSOZWhole{k,9});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,4} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,4} = mean([HFO_interval_nonSOZWhole{k,5},HFO_interval_nonSOZWhole{k,9}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,5}) == 1
                HFO_interval_nonSOZWholeFinal{k,4} = HFO_interval_nonSOZWhole{k,9};
            else 
                HFO_interval_nonSOZWholeFinal{k,4} = HFO_interval_nonSOZWhole{k,5};
            end
    end
   % col5: sleep data_SD
    indicator = isempty(HFO_interval_nonSOZWhole{k,11}) + isempty(HFO_interval_nonSOZWhole{k,15});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,5} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,5} = mean([HFO_interval_nonSOZWhole{k,11},HFO_interval_nonSOZWhole{k,15}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,11}) == 1
                HFO_interval_nonSOZWholeFinal{k,5} = HFO_interval_nonSOZWhole{k,15};
            else 
                HFO_interval_nonSOZWholeFinal{k,5} = HFO_interval_nonSOZWhole{k,11};
            end
    end
    % col6: sleep data_skewness
    indicator = isempty(HFO_interval_nonSOZWhole{k,12}) + isempty(HFO_interval_nonSOZWhole{k,16});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,6} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,6} = mean([HFO_interval_nonSOZWhole{k,12},HFO_interval_nonSOZWhole{k,16}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,12}) == 1
                HFO_interval_nonSOZWholeFinal{k,6} = HFO_interval_nonSOZWhole{k,16};
            else 
                HFO_interval_nonSOZWholeFinal{k,6} = HFO_interval_nonSOZWhole{k,12};
            end
    end
    % col7: sleep data_kurtosis
    indicator = isempty(HFO_interval_nonSOZWhole{k,13}) + isempty(HFO_interval_nonSOZWhole{k,17});
    switch indicator
        case 2
            HFO_interval_nonSOZWholeFinal{k,7} = [];
        case 0
            HFO_interval_nonSOZWholeFinal{k,7} = mean([HFO_interval_nonSOZWhole{k,13},HFO_interval_nonSOZWhole{k,17}]);
        case 1
            if isempty(HFO_interval_nonSOZWhole{k,13}) == 1
                HFO_interval_nonSOZWholeFinal{k,7} = HFO_interval_nonSOZWhole{k,17};
            else 
                HFO_interval_nonSOZWholeFinal{k,7} = HFO_interval_nonSOZWhole{k,13};
            end
    end
end

