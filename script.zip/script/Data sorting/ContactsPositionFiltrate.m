% load atlas
addpath(genpath('C:\Users\LiZilin\Desktop\click_here_to _start_involution\HFO\implantation'))
M = niftiread('Yeo2011_7Networks_MNI152 (Yeo 2011).nii');
Minfo = niftiinfo('Yeo2011_7Networks_MNI152 (Yeo 2011).nii');

% get contacts position
load('electrode.mat');
ContactsPos = electrode.Pos;
ContactsPos(:,4) = 1;

% transform contacts postion into atlas space
ContactsPostionsNewijk = zeros(size(ContactsPos,1),4);

for i = 1 : size(ContactsPos,1)
ContactsPostionsNewijk(i,:) = (inv(Minfo.Transform.T')*ContactsPos(i,:)')';
end

ContactsPostionsNewijk = round(ContactsPostionsNewijk(:,1:3));

% find network
ContactsPosMNI = [];
ContactsPosNet = [];
ContactsName = [];
Radius = 2;
threshold = 0.7;

for j = 1 : size(ContactsPostionsNewijk,1)
    Mcount = [];
    midx = ContactsPostionsNewijk(j,1);
    midy = ContactsPostionsNewijk(j,2);
    midz = ContactsPostionsNewijk(j,3);
    for ix = midx - Radius : midx + Radius
        for iy = midy - Radius : midy + Radius
            for iz = midz - Radius : midz + Radius
                ContactsDist = sqrt((ix-midx)^2+ (iy-midy)^2+ (iz-midz)^2);
                if ContactsDist <= Radius
                    Mcount = [Mcount;M(ix, iy, iz)];
                end
            end
        end
    end
    if length(find(Mcount==1)) + length(find(Mcount==2)) >=  ceil(threshold*length(Mcount))%include contacts in network 1 or 2
        ContactsPosMNI = [ContactsPosMNI; electrode.Pos(j, :)];
        ContactsPosNet = [ContactsPosNet; M(midx, midy, midz)];
        ContactsName = [ContactsName; electrode.Name(j,:)];
    end
end

% save contacts position data
ContactsPosition.MNIspace = ContactsPosMNI;
ContactsPosition.Network = ContactsPosNet;
ContactsPosition.Name = ContactsName;
cd('C:\Users\LiZilin\Desktop\click_here_to _start_involution\HFO\implantation')
save('ContactsPosition.mat', 'ContactsPosition')
