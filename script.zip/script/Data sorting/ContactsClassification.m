%% load all electrode

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\script')
load ContactsInclude.mat
load ContactsPositionwhole.mat
%% load individual data and classification

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data')
load SOZLabel.mat
addpath(genpath('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\interictal'))
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data')
PTlist_TL = textread('PTlist_TL.txt','%s');
PTlist_eTL = textread('PTlist_eTL.txt','%s');
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\interictal\HFOResults')
Contacts.Name = {};
Contacts.Data = [];
Contacts.qualityCheckMask = [];
count = 0;
PTlist = textread('PTlist.txt','%s');
outcome = textread('outcome.txt','%d');


for j = 1 : length(PTlist)
    PT = char(PTlist(j,1));
    
    eval(['[awakeMatrix1,awakeTitle,~] = xlsread([num2str(j),PT, ''_', 'awake1.xlsx'']);'])
    eval(['[awakeMatrix2,~,~] = xlsread([num2str(j),PT, ''_', 'awake2.xlsx'']);'])
    awakeTitle = awakeTitle(2:end,:);
    
    eval(['[sleepMatrix1,sleepTitle,~] = xlsread([num2str(j),PT, ''_', 'sleep1.xlsx'']);'])
    eval(['[sleepMatrix2,~,~] = xlsread([num2str(j),PT, ''_', 'sleep2.xlsx'']);'])
    sleepTitle = sleepTitle(2:end,:);
    
    % Classification
    
    for i = 1 : size(sleepMatrix1,1)
        contactsName = strsplit(sleepTitle{i,1},'-');
        contactsName{1,1} = [PT,char(contactsName{1,1})];
        contactsName{1,2} = [PT,char(contactsName{1,2})];
        [row1,~] = find(strcmp(ContactsPosition.Name, contactsName{1,1}));
        [row2,~] = find(strcmp(ContactsPosition.Name, contactsName{1,2}));
        if isempty(row1)~= 1 && isempty(row2)~= 1
            count = count + 1;
            qualityMask = zeros(1,4);
            Contacts.Name{count,1} = [PT,'_',sleepTitle{i,1}];
            % classify noise contacts, 1 = include, 0 = noise
            if  sleepMatrix1(i,3) == 0 || ~(sleepMatrix1(i,3) <= 0.6*sleepMatrix1(i,1))
                qualityMask(1,1) = 1;
            end
            if  sleepMatrix2(i,3) == 0 || ~(sleepMatrix2(i,3) <= 0.6*sleepMatrix2(i,1))
                qualityMask(1,2) = 1;
            end
            if  awakeMatrix1(i,3) == 0 || ~(awakeMatrix1(i,3) <= 0.6*awakeMatrix1(i,1))
                qualityMask(1,3) = 1;
            end
            if  awakeMatrix2(i,3) == 0 || ~(awakeMatrix2(i,3) <= 0.6*awakeMatrix2(i,1))
                qualityMask(1,4) = 1;
            end
            Contacts.qualityCheckMask = [Contacts.qualityCheckMask; qualityMask];
            % record data for each channel
            ContactsDataIndividual = zeros(1,9);
            % col 1: numbers of candidate HFOs
            ContactsDataIndividual(1,1) = qualityMask(1,1)*sleepMatrix1(i,1) + qualityMask(1,2)*sleepMatrix2(i,1) + qualityMask(1,3)*awakeMatrix1(i,1) + qualityMask(1,4)*awakeMatrix2(i,1);
            % col 2&3: numbers&frequency of quality HFOs
            ContactsDataIndividual(1,2) = qualityMask(1,1)*sleepMatrix1(i,3) + qualityMask(1,2)*sleepMatrix2(i,3) + qualityMask(1,3)*awakeMatrix1(i,3) + qualityMask(1,4)*awakeMatrix2(i,3);
            ContactsDataIndividual(1,3) = ContactsDataIndividual(1,2)/(sum(qualityMask)*10);
            % col 4&5: numbers&frequency of FR
            ContactsDataIndividual(1,4) = qualityMask(1,1)*sleepMatrix1(i,5) + qualityMask(1,2)*sleepMatrix2(i,5) + qualityMask(1,3)*awakeMatrix1(i,5) + qualityMask(1,4)*awakeMatrix2(i,5);
            ContactsDataIndividual(1,5) = ContactsDataIndividual(1,4)/(sum(qualityMask)*10);
            % col 6: whether the bipolar is patho or not
            Label = [PT,'_',sleepTitle{i,1}];
            if ismember(Label,SOZ_HFOLabel) == 1
                ContactsDataIndividual(1,6) = 1;
            end
            % col 7: whether the bipolar is in net 1 or 2
            if ismember(Label,SOZ_HFOLabel) ~= 1
                if ismember(contactsName(1,1),ContactsInclude.Name) == 1 || ismember(contactsName(1,2),ContactsInclude.Name) == 1
                    ContactsDataIndividual(1,7) = 1;
                end
            end
            % col 8: surgical outcome
            ContactsDataIndividual(1,8) = outcome(j,1);
            % col 9: whether the patient is TLE or eTLE
            if ismember(PT,PTlist_TL) == 1
                ContactsDataIndividual(1,9) = 1;
            elseif ismember(PT,PTlist_eTL) == 1
                ContactsDataIndividual(1,9) = 0;
            else
                ContactsDataIndividual(1,9) = 99;
            end
            
            Contacts.Data = [Contacts.Data; ContactsDataIndividual];
        end
    end
end

ContactsFinal.Name = [];
ContactsFinal.Data = [];
ContactsFinal.Mask = [];

for k = 1 : length(Contacts.Name)
    if sum(Contacts.qualityCheckMask(k,:)) == 4
        ContactsFinal.Name = [ContactsFinal.Name; Contacts.Name(k,1)];
        ContactsFinal.Data = [ContactsFinal.Data; Contacts.Data(k,:)];
        ContactsFinal.Mask = [ContactsFinal.Mask; Contacts.qualityCheckMask(k,:)];
    end
end

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\rawHFOResults')
save('ContactsFinal.mat','ContactsFinal')
%% calculate subgroup
% subgroup: SOZ, nonSOZ, NET_nonSOZ, nonNET_nonSOZ

SOZ = [];
nonSOZ = [];
NET_nonSOZ = [];
nonNET_nonSOZ = [];
SOZ_TL = [];
SOZ_eTL = [];

for k = 1 : size(Contacts.Data,1)
    if Contacts.Data(k,6) == 1
        SOZ = [SOZ; Contacts.Data(k, :)];
        if Contacts.Data(k,9) == 1
            SOZ_TL = [SOZ_TL;Contacts.Data(k, :)];
        elseif Contacts.Data(k,9) == 0
            SOZ_eTL = [SOZ_eTL;Contacts.Data(k, :)];
        end
    else
        nonSOZ = [nonSOZ; Contacts.Data(k, :)];
    end
    if Contacts.Data(k,6) == 0 && Contacts.Data(k,7) == 1
        NET_nonSOZ = [NET_nonSOZ; Contacts.Data(k, :)];
    elseif Contacts.Data(k,6) == 0 && Contacts.Data(k,7) == 0
        nonNET_nonSOZ = [nonNET_nonSOZ; Contacts.Data(k, :)];
    end
end

%% calculate HFO
% frequency of quality HFOs
mean_SOZ = nansum(SOZ(:,3))/sum(~isnan(SOZ(:,3)));
mean_nonSOZ = nansum(nonSOZ(:,3))/sum(~isnan(nonSOZ(:,3)));
mean_NET_nonSOZ = nansum(NET_nonSOZ(:,3))/sum(~isnan(NET_nonSOZ(:,3)));
mean_nonNET_nonSOZ = nansum(nonNET_nonSOZ(:,3))/sum(~isnan(nonNET_nonSOZ(:,3)));
mean_SOZ_TL = nansum(SOZ_TL(:,3))/sum(~isnan(SOZ_TL(:,3)));
mean_SOZ_eTL = nansum(SOZ_eTL(:,3))/sum(~isnan(SOZ_eTL(:,3)));

%
HFOsFrequency_SOZ = SOZ(:,3);
HFOsFrequency_SOZ = HFOsFrequency_SOZ(~isnan(HFOsFrequency_SOZ));

HFOsFrequency_nonSOZ = nonSOZ(:,3);
HFOsFrequency_nonSOZ = HFOsFrequency_nonSOZ(~isnan(HFOsFrequency_nonSOZ));

HFOsFrequency_NET = NET_nonSOZ(:,3);
HFOsFrequency_NET = HFOsFrequency_NET(~isnan(HFOsFrequency_NET));

HFOsFrequency_nonNET = nonNET_nonSOZ(:,3);
HFOsFrequency_nonNET = HFOsFrequency_nonNET(~isnan(HFOsFrequency_nonNET));

HFOsFrequency_SOZ_TL = SOZ_TL(:,3);
HFOsFrequency_SOZ_TL = HFOsFrequency_SOZ_TL(~isnan(HFOsFrequency_SOZ_TL));

HFOsFrequency_SOZ_eTL = SOZ_eTL(:,3);
HFOsFrequency_SOZ_eTL = HFOsFrequency_SOZ_eTL(~isnan(HFOsFrequency_SOZ_eTL));


HFOsFrequency_SOZ = HFOsFrequency_SOZ(HFOsFrequency_SOZ<20);


HFOsFrequency_nonSOZ = HFOsFrequency_nonSOZ(HFOsFrequency_nonSOZ<20);


HFOsFrequency_NET = HFOsFrequency_NET(HFOsFrequency_NET<20);


HFOsFrequency_nonNET = HFOsFrequency_nonNET(HFOsFrequency_nonNET<20);


HFOsFrequency_SOZ_TL = HFOsFrequency_SOZ_TL(HFOsFrequency_SOZ_TL<20);


HFOsFrequency_SOZ_eTL = HFOsFrequency_SOZ_eTL(HFOsFrequency_SOZ_eTL<20);


HFOsFrequency_SOZ_sleep = HFOsFrequency_SOZ_sleep(HFOsFrequency_SOZ_sleep<20 );


HFOsFrequency_nonSOZ_sleep = HFOsFrequency_nonSOZ_sleep(HFOsFrequency_nonSOZ_sleep<20 );


HFOsFrequency_SOZ_awake = HFOsFrequency_SOZ_awake(HFOsFrequency_SOZ_awake<20);


HFOsFrequency_nonSOZ_awake = HFOsFrequency_nonSOZ_awake(HFOsFrequency_nonSOZ_awake<20);
save('forRplot_frequency.mat','HFOsFrequency_SOZ','HFOsFrequency_nonSOZ','HFOsFrequency_NET','HFOsFrequency_nonNET','HFOsFrequency_SOZ_TL','HFOsFrequency_SOZ_eTL')

[h, p] = ranksum(HFOsFrequency_NET_Awake,HFOsFrequency_nonNET_Awake)

