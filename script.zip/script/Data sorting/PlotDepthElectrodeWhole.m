%% load atlas
addpath(genpath('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\implantation'))
M = niftiread('Yeo2011_7Networks_MNI152 (Yeo 2011).nii');
Minfo = niftiinfo('Yeo2011_7Networks_MNI152 (Yeo 2011).nii');

% get contacts position
load('electrode.mat');
ContactsPos = electrode.Pos;
ContactsPos(:,4) = 1;

% transform contacts postion into atlas space
ContactsPositionsNewijk = zeros(size(ContactsPos,1),4);

for i = 1 : size(ContactsPos,1)
    ContactsPositionsNewijk(i,:) = (inv(Minfo.Transform.T')*ContactsPos(i,:)')';
end

ContactsPositionsNewijk = round(ContactsPositionsNewijk(:,1:3));
ContactsPosNet = zeros(size(ContactsPositionsNewijk,1),1);

%% find network

Radius = 2;
threshold = 0.7;

for j = 1 : size(ContactsPositionsNewijk,1)
    Mcount = [];
    midx = ContactsPositionsNewijk(j,1);
    midy = ContactsPositionsNewijk(j,2);
    midz = ContactsPositionsNewijk(j,3);
    for ix = midx - Radius : midx + Radius
        for iy = midy - Radius : midy + Radius
            for iz = midz - Radius : midz + Radius
                ContactsDist = sqrt((ix-midx)^2+ (iy-midy)^2+ (iz-midz)^2);
                if ContactsDist <= Radius
                    Mcount = [Mcount;M(ix, iy, iz)];
                end
            end
        end
    end
    if length(find(Mcount==1))  >=  ceil(threshold*length(Mcount))%include contacts in network 1 
        ContactsPosNet(j, 1) = 1;
    elseif  length(find(Mcount==2))  >=  ceil(threshold*length(Mcount))
        ContactsPosNet(j, 1) = 2;
    elseif length(find(Mcount==0))  >=  ceil(0.6*length(Mcount))
        ContactsPosNet(j, 1) = 0;
    else
        ContactsPosNet(j, 1) = 3;
    end
end

 ContactsCoords = [];
 ContactsNet = [];
 ContactsNames = [];
 
 for a = 1 : size(ContactsPositionsNewijk,1)
     if ContactsPosNet(a, 1) ~= 0
         ContactsCoords = [ContactsCoords; electrode.Pos(a,:)];
         ContactsNet = [ContactsNet; ContactsPosNet(a, 1)];
         ContactsNames = [ContactsNames; electrode.Name(a,1)];
     end
 end
 

% save contacts position data
ContactsPosition.Coords = ContactsCoords;
ContactsPosition.Network = ContactsNet;
ContactsPosition.Name = ContactsNames;
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\implantation')
save('ContactsPositionwhole.mat', 'ContactsPosition')

%% get electrode in network 1 or 2
ContactsCoordsInclude = [];
ContactsNetInclude = [];
ContactsNamesInclude = [];
for b = 1 : size(ContactsPosition.Network, 1)
    if ContactsPosition.Network(b,1) == 1 || ContactsPosition.Network(b,1) == 2
        ContactsCoordsInclude = [ContactsCoordsInclude; ContactsPosition.Coords(b,:)];
        ContactsNetInclude = [ContactsNetInclude; ContactsPosition.Network(b,1)];
        ContactsNamesInclude = [ContactsNamesInclude; ContactsPosition.Name(b,1)];
    end
end
ContactsInclude.Coords = ContactsCoordsInclude;
ContactsInclude.Net = ContactsNetInclude;
ContactsInclude.Name = ContactsNamesInclude;
save('ContactsInclude.mat', 'ContactsInclude')

%% plot depth electrode

addpath(genpath('C:\Users\LiZilin\Desktop\click-here-to -start-involution\Pointing_brain\iELVis-master'))

load ContactsPositionwhole.mat
load cdcol.mat
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\rawHFOResults')
load ContactsFinal.mat

groupAvgCoordsLh = [];
groupAvgCoordsRh = [];
groupNetworkLh = [];
groupNetworkRh = [];
groupLabelsLh = [];
groupLabelsRh = [];
groupIsPathoLh = [];
groupIsPathoRh = [];

ContactsFinalNameSingle = {};
for ii = 1 : length(ContactsFinal.Name)
    tempName = strsplit(ContactsFinal.Name{ii},'_');
    tempContact = strsplit(tempName{2},'-');
    NameSingle = {[tempName{1},tempContact{1}];[tempName{1},tempContact{2}]};
    ContactsFinalNameSingle = [ContactsFinalNameSingle;NameSingle];
end

for k = 1 : size(ContactsPosition.Coords,1)
    if ismember(ContactsPosition.Name(k),ContactsFinalNameSingle) == 1
%        if ContactsPosition.isPatho(k) == 0
            if ContactsPosition.Coords(k,1) < 0
                groupAvgCoordsLh = [groupAvgCoordsLh; ContactsPosition.Coords(k,:)];
                groupNetworkLh = [groupNetworkLh; ContactsPosition.Network(k,:)];
                groupLabelsLh = [groupLabelsLh; ContactsPosition.Name(k,:)];
                groupIsPathoLh = [groupIsPathoLh;ContactsPosition.isPatho(k,:)];
            else
                groupAvgCoordsRh = [groupAvgCoordsRh; ContactsPosition.Coords(k,:)];
                groupNetworkRh = [groupNetworkRh; ContactsPosition.Network(k,:)];
                groupLabelsRh = [groupLabelsRh; ContactsPosition.Name(k,:)];
                groupIsPathoRh = [groupIsPathoRh;ContactsPosition.isPatho(k,:)];
            end
%        end
    end
end

groupIsLeftRh = zeros(size(groupAvgCoordsRh,1),1);
groupIsLeftLh = ones(size(groupAvgCoordsLh,1),1);

% load atlas
createIndivYeoMapping('PT058');

% plot right hemisphere
[~, ~, col]=read_annotation(fullfile(getFsurfSubDir(),'fsaverage','label','rh.Yeo2011_7Networks_N1000.annot'));
id = [2 3];
% Make verteces gray
parc_col = .7.*255.*ones(size(col.table(:,1:3)));
% Color parcel of interest
parc_col(id,:)=col.table(id,1:3);
cfg=[];
% cfg.ignoreDepthElec='n';

colorRh = zeros(size(groupAvgCoordsRh,1),3);
for m = 1 : size(groupAvgCoordsRh,1)
    if groupIsPathoRh(m,1) == 1
        colorRh(m,:) = cdcol.scarlet;
    elseif groupNetworkRh(m,1) == 1
        colorRh(m,:) = cdcol.purple;
    elseif groupNetworkRh(m,1) == 2
        colorRh(m,:) = cdcol.darkulamarine;
    else
        colorRh(m,:) = cdcol.lightgrey;
    end
end

cfg.surfType='inflated';
cfg.opaqueness = 1;
cfg.elecCoord=[groupAvgCoordsRh groupIsLeftRh];
cfg.elecNames=groupLabelsRh;
cfg.parcellationColors = parc_col;
cfg.showLabels='n';
cfg.edgeBlack='y';
cfg.elecColors = colorRh;
cfg.ignoreDepthElec='n';
cfg.elecColorScale=[0 1];
cfg.elecSize = 1.5;
cfg.elecShape = 'sphere';
cfg.overlayParcellation='Y7';

cfg.view='r';
cfgOut=plotPialSurf('fsaverage',cfg);

cfg.view='rm';
cfgOut=plotPialSurf('fsaverage',cfg);

cfg.view='ri';
cfgOut=plotPialSurf('fsaverage',cfg);

% plot left hemisphere
[~, ~, col]=read_annotation(fullfile(getFsurfSubDir(),'fsaverage','label','lh.Yeo2011_7Networks_N1000.annot'));
id = [2 3];
% Make verteces gray
parc_col = .7.*255.*ones(size(col.table(:,1:3)));
% Color parcel of interest
parc_col(id,:)=col.table(id,1:3);
cfg=[];
% cfg.ignoreDepthElec='n';

colorLh = zeros(size(groupAvgCoordsLh,1),3);
for n = 1 : size(groupAvgCoordsLh,1)
    if groupIsPathoLh(n,1) == 1
        colorLh(n,:) = cdcol.scarlet;
    elseif groupNetworkLh(n,1) == 1
         colorLh(n,:) = cdcol.purple;
    elseif groupNetworkLh(n,1) == 2
         colorLh(n,:) = cdcol.darkulamarine;
    else
        colorLh(n,:) = cdcol.lightgrey;
    end
end

cfg.surfType='inflated';
cfg.opaqueness = 1;
cfg.elecCoord=[groupAvgCoordsLh groupIsLeftLh];
cfg.elecNames=groupLabelsLh;
cfg.parcellationColors = parc_col;
cfg.showLabels='n';
cfg.edgeBlack='y';
cfg.elecColors = colorLh;
cfg.ignoreDepthElec='n';
cfg.elecColorScale=[0 1];
cfg.elecSize = 1.5;
cfg.elecShape = 'sphere';
cfg.overlayParcellation='Y7';

cfg.view='l';
cfgOut=plotPialSurf('fsaverage',cfg);

cfg.view='lm';
cfgOut=plotPialSurf('fsaverage',cfg);

cfg.view='li';
cfgOut=plotPialSurf('fsaverage',cfg);