# -*- coding: utf-8 -*-
#Data imports

import pandas as pd

import numpy as np

#Visualization imports

import matplotlib.pyplot as plt

import scipy.io as sio

import os

os.chdir('C:/Users/LiZilin/Desktop/click-here-to -start-involution/HFO/ML')

load_plane = os.path.join(os.getcwd(),'traindata.mat')  #mat文件路径

plane = sio.loadmat(load_plane)  

plane['feature_name'] = ['stereo','skew','kurt','PAC']

raw_data = pd.DataFrame(plane['trainMatrix'][:,0:4], columns = plane['feature_name'])

#Split the data set into training data and test data

x = raw_data

y = plane['trainMatrix'][:,4]

from sklearn.model_selection import train_test_split

x_training_data, x_test_data, y_training_data, y_test_data = train_test_split(x, y, test_size = 0.25)

from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix

# XgBoost model
import xgboost as xgb

from xgboost import plot_importance

model = xgb.XGBClassifier(
    silent=0,  # 设置成1则没有运行信息输出，最好是设置为0，是否在运行升级时打印消息
    learning_rate=0.1 , # 如同学习率
    min_child_weight = 1,
    max_depth=6, # 构建树的深度，越大越容易过拟合
    gamma = 0,# 树的叶子节点上做进一步分区所需的最小损失减少，越大越保守，一般0.1 0.2这样子
    subsample=1, # 随机采样训练样本，训练实例的子采样比
    max_delta_step=0,  # 最大增量步长，我们允许每个树的权重估计
    colsample_bytree=1, # 生成树时进行的列采样
    reg_lambda=1, #控制模型复杂度的权重值的L2正则化项参数，参数越大，模型越不容易过拟合
    n_estimators=160,  # 树的个数
    seed = 1000,
    num_class=2,
    objective='multi:softmax')

model.fit(x_training_data, y_training_data)

# 对测试集进行预测
y_pred = model.predict(x_test_data)
 
#计算准确率
print(classification_report(y_test_data, y_pred))

#显示混淆矩阵
print(confusion_matrix(y_test_data,y_pred))
 
# 显示重要特征
plot_importance(model)

plt.show()

# feature importance
from sklearn.inspection import permutation_importance

perm_importance = permutation_importance(model, x_test_data, y_test_data)

feature_names = plane['feature_name']

features = np.array(feature_names)

sorted_idx = perm_importance.importances_mean.argsort()

plt.barh(features[sorted_idx], perm_importance.importances_mean[sorted_idx])

plt.xlabel("Permutation Importance")

#ROC curve
from sklearn import metrics
display = metrics.plot_roc_curve(model,x_test_data, y_test_data)

print('type(display):',type(display))

plt.show()

# adjust parameters
# min_child_weight&max_depth
param_test1 = {
 'max_depth':range(3,10,2),
 'min_child_weight':range(1,6,2)
}

from sklearn.model_selection import GridSearchCV

gsearch1 = GridSearchCV(
    estimator = xgb.XGBClassifier(
    silent=0,  # 设置成1则没有运行信息输出，最好是设置为0，是否在运行升级时打印消息
    learning_rate=0.3 , # 如同学习率
    min_child_weight = 1,
    max_depth=6, # 构建树的深度，越大越容易过拟合
    gamma = 0.1,# 树的叶子节点上做进一步分区所需的最小损失减少，越大越保守，一般0.1 0.2这样子
    subsample=1, # 随机采样训练样本，训练实例的子采样比
    max_delta_step=0,  # 最大增量步长，我们允许每个树的权重估计
    colsample_bytree=1, # 生成树时进行的列采样
    reg_lambda=1, #控制模型复杂度的权重值的L2正则化项参数，参数越大，模型越不容易过拟合
    n_estimators=160,  # 树的个数
    seed = 1000, ),
param_grid = param_test1,
scoring='roc_auc',
n_jobs=4,
cv=5)

gsearch1.fit(x_training_data, y_training_data)

gsearch1.best_params_,gsearch1.best_score_

#gamma

param_test3 = {
 'gamma':[i/10.0 for i in range(0,5)]
}
 
gsearch3 = GridSearchCV(
    estimator = xgb.XGBClassifier(
    silent=0,  # 设置成1则没有运行信息输出，最好是设置为0，是否在运行升级时打印消息
    learning_rate=0.3 , # 如同学习率
    min_child_weight = 1,
    max_depth=7, # 构建树的深度，越大越容易过拟合
    gamma = 0.1,# 树的叶子节点上做进一步分区所需的最小损失减少，越大越保守，一般0.1 0.2这样子
    subsample=1, # 随机采样训练样本，训练实例的子采样比
    max_delta_step=0,  # 最大增量步长，我们允许每个树的权重估计
    colsample_bytree=1, # 生成树时进行的列采样
    reg_lambda=1, #控制模型复杂度的权重值的L2正则化项参数，参数越大，模型越不容易过拟合
    n_estimators=160,  # 树的个数
    seed = 1000,  ),
param_grid = param_test3,
scoring='roc_auc',
n_jobs=4,
cv=5)
    
gsearch3.fit(x_training_data, y_training_data)
 
gsearch3.best_params_, gsearch3.best_score_

#subsample&colsample_bytree

param_test4 = {
 'subsample':[i/10.0 for i in range(6,10)],
 'colsample_bytree':[i/10.0 for i in range(6,10)]
}
  
gsearch4 = GridSearchCV(
    estimator = xgb.XGBClassifier(
    silent=0,  # 设置成1则没有运行信息输出，最好是设置为0，是否在运行升级时打印消息
    learning_rate=0.3 , # 如同学习率
    min_child_weight = 1,
    max_depth=7, # 构建树的深度，越大越容易过拟合
    gamma = 0.4,# 树的叶子节点上做进一步分区所需的最小损失减少，越大越保守，一般0.1 0.2这样子
    subsample=1, # 随机采样训练样本，训练实例的子采样比
    max_delta_step=0,  # 最大增量步长，我们允许每个树的权重估计
    colsample_bytree=1, # 生成树时进行的列采样
    reg_lambda=1, #控制模型复杂度的权重值的L2正则化项参数，参数越大，模型越不容易过拟合
    n_estimators=160,  # 树的个数
    seed = 1000,  ),
param_grid = param_test4,
scoring='roc_auc',
n_jobs=4,
cv=5)

gsearch4.fit(x_training_data, y_training_data)

gsearch4.best_params_, gsearch4.best_score_

# final model

model_final = xgb.XGBClassifier(
    silent=0,  # 设置成1则没有运行信息输出，最好是设置为0，是否在运行升级时打印消息
    learning_rate=0.3 , # 如同学习率
    min_child_weight = 1,
    max_depth=7, # 构建树的深度，越大越容易过拟合
    gamma = 0.4,# 树的叶子节点上做进一步分区所需的最小损失减少，越大越保守，一般0.1 0.2这样子
    subsample=0.7, # 随机采样训练样本，训练实例的子采样比
    max_delta_step=0,  # 最大增量步长，我们允许每个树的权重估计
    colsample_bytree=0.6, # 生成树时进行的列采样
    reg_lambda=1, #控制模型复杂度的权重值的L2正则化项参数，参数越大，模型越不容易过拟合
    n_estimators=160,  # 树的个数
    seed = 1000, 
    )

model_final.fit(x_training_data, y_training_data)

y_pred_final = model_final.predict(x_test_data)
 
#计算准确率
print(classification_report(y_test_data, y_pred_final))

#显示混淆矩阵
print(confusion_matrix(y_test_data,y_pred_final))
 
# 显示重要特征
plot_importance(model_final)

plt.show()

#ROC curve

display = metrics.plot_roc_curve(model_final,x_test_data, y_test_data)

print('type(display):',type(display))

plt.show()

# save model
import joblib

joblib.dump(model,'model.dat')
joblib.dump(model_final,'model_final.dat')

