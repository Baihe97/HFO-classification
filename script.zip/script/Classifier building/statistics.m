%% load data
cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\awake_sleep_data')
load stereotype_nonSOZ.mat
load stereotype_SOZ.mat
load rhythmic_nonSOZ.mat
load rhythmic_SOZ.mat
load PAC_nonSOZ.mat
load PAC_SOZ.mat

%% stereotpye_R awake&sleep

stereoAwakeSOZ_R = [];
stereoSleepSOZ_R = [];
stereoAwakenonSOZ_R = [];
stereoSleepnonSOZ_R = [];
% SOZ
for i = 1 : length(HFO_stereo_SOZWholeFinal)
    if isempty(HFO_stereo_SOZWholeFinal{i,2}) ~= 1
        stereoAwakeSOZ_R = [stereoAwakeSOZ_R;HFO_stereo_SOZWholeFinal{i,2}];
    end
    if isempty(HFO_stereo_SOZWholeFinal{i,3}) ~= 1
        stereoSleepSOZ_R = [stereoSleepSOZ_R;HFO_stereo_SOZWholeFinal{i,3}];
    end
end
% nonSOZ
for j = 1 : length(HFO_stereo_nonSOZWholeFinal)
    if isempty(HFO_stereo_nonSOZWholeFinal{j,2}) ~= 1
        stereoAwakenonSOZ_R = [stereoAwakenonSOZ_R;HFO_stereo_nonSOZWholeFinal{j,2}];
    end
    if isempty(HFO_stereo_nonSOZWholeFinal{j,3}) ~= 1
        stereoSleepnonSOZ_R = [stereoSleepnonSOZ_R;HFO_stereo_nonSOZWholeFinal{j,3}];
    end
end

h_SOZsleep = lillietest(stereoSleepSOZ_R)
h_SOZawake = lillietest(stereoAwakeSOZ_R)
h_nonSOZsleep = lillietest(stereoSleepnonSOZ_R)
h_nonSOZawake = lillietest(stereoAwakenonSOZ_R)


p_sleep = ranksum(stereoSleepSOZ_R,stereoSleepnonSOZ_R)
p_awake = ranksum(stereoSleepnonSOZ_R,stereoAwakenonSOZ_R)

%% rhythmic_SD awake&sleep

rhythmicAwakeSOZ_SD = [];
rhythmicSleepSOZ_SD = [];
rhythmicAwakenonSOZ_SD = [];
rhythmicSleepnonSOZ_SD = [];

for i = 1 : length(HFO_interval_SOZWholeFinal)
    if isempty(HFO_interval_SOZWholeFinal{i,2}) ~= 1
        rhythmicAwakeSOZ_SD = [rhythmicAwakeSOZ_SD;HFO_interval_SOZWholeFinal{i,2}];
    end
    if isempty(HFO_interval_SOZWholeFinal{i,5}) ~= 1
        rhythmicSleepSOZ_SD = [rhythmicSleepSOZ_SD;HFO_interval_SOZWholeFinal{i,5}];
    end
    if isempty(HFO_interval_nonSOZWholeFinal{i,2}) ~= 1
        rhythmicAwakenonSOZ_SD = [rhythmicAwakenonSOZ_SD;HFO_interval_nonSOZWholeFinal{i,2}];
    end
    if isempty(HFO_interval_nonSOZWholeFinal{i,5}) ~= 1
        rhythmicSleepnonSOZ_SD = [rhythmicSleepnonSOZ_SD;HFO_interval_nonSOZWholeFinal{i,5}];
    end
end

h_SOZsleep = lillietest(rhythmicSleepSOZ_SD)
h_SOZawake = lillietest(rhythmicAwakeSOZ_SD)
h_nonSOZsleep = lillietest(rhythmicSleepnonSOZ_SD)
h_nonSOZawake = lillietest(rhythmicAwakenonSOZ_SD)

p_sleep = ranksum(rhythmicSleepSOZ_SD,rhythmicSleepnonSOZ_SD)
p_awake = ranksum(rhythmicAwakeSOZ_SD,rhythmicAwakenonSOZ_SD)

%% rhythmic_skewness awake&sleep
rhythmicAwakeSOZ_skewness = [];
rhythmicSleepSOZ_skewness = [];
rhythmicAwakenonSOZ_skewness = [];
rhythmicSleepnonSOZ_skewness = [];
% SOZ
for i = 1 : length(HFO_interval_SOZWholeFinal)
    if isempty(HFO_interval_SOZWholeFinal{i,3}) ~= 1
        rhythmicAwakeSOZ_skewness = [rhythmicAwakeSOZ_skewness;HFO_interval_SOZWholeFinal{i,3}];
    end
    if isempty(HFO_interval_SOZWholeFinal{i,6}) ~= 1
        rhythmicSleepSOZ_skewness = [rhythmicSleepSOZ_skewness;HFO_interval_SOZWholeFinal{i,6}];
    end
end
% nonSOZ
for j = 1 : length(HFO_interval_nonSOZWholeFinal)
    if isempty(HFO_interval_nonSOZWholeFinal{j,3}) ~= 1
        rhythmicAwakenonSOZ_skewness = [rhythmicAwakenonSOZ_skewness;HFO_interval_nonSOZWholeFinal{j,3}];
    end
    if isempty(HFO_interval_nonSOZWholeFinal{j,6}) ~= 1
        rhythmicSleepnonSOZ_skewness = [rhythmicSleepnonSOZ_skewness;HFO_interval_nonSOZWholeFinal{j,6}];
    end
end

h_SOZsleep = lillietest(rhythmicSleepSOZ_skewness)
h_SOZawake = lillietest(rhythmicAwakeSOZ_skewness)
h_nonSOZsleep = lillietest(rhythmicSleepnonSOZ_skewness)
h_nonSOZawake = lillietest(rhythmicAwakenonSOZ_skewness)

p_sleep = ranksum(rhythmicSleepSOZ_skewness,rhythmicSleepnonSOZ_skewness)
p_awake = ranksum(rhythmicAwakeSOZ_skewness,rhythmicAwakenonSOZ_skewness)

%% rhythmic_kurtosis awake&sleep
rhythmicAwakeSOZ_kurtosis = [];
rhythmicSleepSOZ_kurtosis = [];
rhythmicAwakenonSOZ_kurtosis = [];
rhythmicSleepnonSOZ_kurtosis = [];
% SOZ
for i = 1 : length(HFO_interval_SOZWholeFinal)
    if isempty(HFO_interval_SOZWholeFinal{i,4}) ~= 1
        rhythmicAwakeSOZ_kurtosis = [rhythmicAwakeSOZ_kurtosis;HFO_interval_SOZWholeFinal{i,4}];
    end
    if isempty(HFO_interval_SOZWholeFinal{i,7}) ~= 1
        rhythmicSleepSOZ_kurtosis = [rhythmicSleepSOZ_kurtosis;HFO_interval_SOZWholeFinal{i,7}];
    end
end
% nonSOZ
for j = 1 : length(HFO_interval_nonSOZWholeFinal)
    if isempty(HFO_interval_nonSOZWholeFinal{j,4}) ~= 1
        rhythmicAwakenonSOZ_kurtosis = [rhythmicAwakenonSOZ_kurtosis;HFO_interval_nonSOZWholeFinal{j,4}];
    end
    if isempty(HFO_interval_nonSOZWholeFinal{j,7}) ~= 1
        rhythmicSleepnonSOZ_kurtosis = [rhythmicSleepnonSOZ_kurtosis;HFO_interval_nonSOZWholeFinal{j,7}];
    end
end

h_SOZsleep = lillietest(rhythmicSleepSOZ_kurtosis)
h_SOZawake = lillietest(rhythmicAwakeSOZ_kurtosis)
h_nonSOZsleep = lillietest(rhythmicSleepnonSOZ_kurtosis)
h_nonSOZawake = lillietest(rhythmicAwakenonSOZ_kurtosis)

p_sleep = ranksum(rhythmicSleepSOZ_kurtosis,rhythmicSleepnonSOZ_kurtosis)
p_awake = ranksum(rhythmicAwakeSOZ_kurtosis,rhythmicAwakenonSOZ_kurtosis)

%% PAC awake&sleep
pacAwakeSOZ = [];
pacSleepSOZ = [];
pacAwakenonSOZ = [];
pacSleepnonSOZ = [];
% SOZ
for i = 1 : length(HFO_pac_SOZWholeFinal)
    if isempty(HFO_pac_SOZWholeFinal{i,2}) ~= 1
        pacAwakeSOZ = [pacAwakeSOZ;HFO_pac_SOZWholeFinal{i,2}];
    end
    if isempty(HFO_pac_SOZWholeFinal{i,3}) ~= 1
        pacSleepSOZ = [pacSleepSOZ;HFO_pac_SOZWholeFinal{i,3}];
    end
end
% nonSOZ
for j = 1 : length(HFO_pac_nonSOZWholeFinal)
    if isempty(HFO_pac_nonSOZWholeFinal{j,2}) ~= 1
        pacAwakenonSOZ = [pacAwakenonSOZ;HFO_pac_nonSOZWholeFinal{j,2}];
    end
    if isempty(HFO_pac_nonSOZWholeFinal{j,3}) ~= 1
        pacSleepnonSOZ = [pacSleepnonSOZ;HFO_pac_nonSOZWholeFinal{j,3}];
    end
end

h_SOZsleep = lillietest(pacSleepSOZ)
h_SOZawake = lillietest(pacAwakeSOZ)
h_nonSOZsleep = lillietest(pacSleepnonSOZ)
h_nonSOZawake = lillietest(pacAwakenonSOZ)

p_sleep = ranksum(pacSleepSOZ,pacSleepnonSOZ)
p_awake = ranksum(pacAwakeSOZ,pacAwakenonSOZ)

%% stereotpye_R whole
% SOZ
HFO_stereo_R_SOZwhole = cell(size(HFO_stereo_SOZWholeFinal,1),2);
HFO_stereo_R_SOZwhole(:,1) = HFO_stereo_SOZWholeFinal(:,2);
HFO_stereo_R_SOZwhole(:,2) = HFO_stereo_SOZWholeFinal(:,3);
HFO_stereo_R_SOZwholeSum = zeros(length(HFO_stereo_R_SOZwhole),1);
for i = 1 : length(HFO_stereo_R_SOZwhole)
    indicator = length(HFO_stereo_R_SOZwhole{i,1}) + length(HFO_stereo_R_SOZwhole{i,2});
    switch indicator
        case 0
            HFO_stereo_R_SOZwholeSum(i) = NaN;
        case 1
            if length(HFO_stereo_R_SOZwhole{i,1}) == 1
                HFO_stereo_R_SOZwholeSum(i) = HFO_stereo_R_SOZwhole{i,1};
            else
                HFO_stereo_R_SOZwholeSum(i) = HFO_stereo_R_SOZwhole{i,2};
            end
        case 2
            HFO_stereo_R_SOZwholeSum(i) = mean([HFO_stereo_R_SOZwhole{i,1},HFO_stereo_R_SOZwhole{i,2}]);
    end
end

% nonSOZ
HFO_stereo_R_nonSOZwhole = cell(size(HFO_stereo_nonSOZWholeFinal,1),2);
HFO_stereo_R_nonSOZwhole(:,1) = HFO_stereo_nonSOZWholeFinal(:,2);
HFO_stereo_R_nonSOZwhole(:,2) = HFO_stereo_nonSOZWholeFinal(:,3);
HFO_stereo_R_nonSOZwholeSum = zeros(length(HFO_stereo_R_nonSOZwhole),1);
for i = 1 : length(HFO_stereo_R_nonSOZwhole)
    indicator = length(HFO_stereo_R_nonSOZwhole{i,1}) + length(HFO_stereo_R_nonSOZwhole{i,2});
    switch indicator
        case 0
            HFO_stereo_R_nonSOZwholeSum(i) = NaN;
        case 1
            if length(HFO_stereo_R_nonSOZwhole{i,1}) == 1
                HFO_stereo_R_nonSOZwholeSum(i) = HFO_stereo_R_nonSOZwhole{i,1};
            else
                HFO_stereo_R_nonSOZwholeSum(i) = HFO_stereo_R_nonSOZwhole{i,2};
            end
        case 2
            HFO_stereo_R_nonSOZwholeSum(i) = mean([HFO_stereo_R_nonSOZwhole{i,1},HFO_stereo_R_nonSOZwhole{i,2}]);
    end
end

p = ranksum(HFO_stereo_R_SOZwholeSum,HFO_stereo_R_nonSOZwholeSum)
diff = mean(HFO_stereo_R_SOZwholeSum(find(isnan(HFO_stereo_R_SOZwholeSum)~=1)))-mean(HFO_stereo_R_nonSOZwholeSum(find(isnan(HFO_stereo_R_nonSOZwholeSum)~=1)))

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\whole_data')
save('stereotype_SOZ_whole.mat','HFO_stereo_R_SOZwholeSum')
save('stereotype_nonSOZ_whole.mat','HFO_stereo_R_nonSOZwholeSum')

%% rhythmic_SD whole
% SOZ
HFO_interval_SD_SOZwhole = cell(size(HFO_interval_SOZWholeFinal,1),2);
HFO_interval_SD_SOZwhole(:,1) = HFO_interval_SOZWholeFinal(:,2);
HFO_interval_SD_SOZwhole(:,2) = HFO_interval_SOZWholeFinal(:,5);
HFO_interval_SD_SOZwholeSum = zeros(length(HFO_interval_SD_SOZwhole),1);
for i = 1 : length(HFO_interval_SD_SOZwhole)
    indicator = length(HFO_interval_SD_SOZwhole{i,1}) + length(HFO_interval_SD_SOZwhole{i,2});
    switch indicator
        case 0
            HFO_interval_SD_SOZwholeSum(i) = NaN;
        case 1
            if length(HFO_interval_SD_SOZwhole{i,1}) == 1
                HFO_interval_SD_SOZwholeSum(i) = HFO_interval_SD_SOZwhole{i,1};
            else
                HFO_interval_SD_SOZwholeSum(i) = HFO_interval_SD_SOZwhole{i,2};
            end
        case 2
            HFO_interval_SD_SOZwholeSum(i) = mean([HFO_interval_SD_SOZwhole{i,1},HFO_interval_SD_SOZwhole{i,2}]);
    end
end

% nonSOZ
HFO_interval_SD_nonSOZwhole = cell(size(HFO_interval_nonSOZWholeFinal,1),2);
HFO_interval_SD_nonSOZwhole(:,1) = HFO_interval_nonSOZWholeFinal(:,2);
HFO_interval_SD_nonSOZwhole(:,2) = HFO_interval_nonSOZWholeFinal(:,5);
HFO_interval_SD_nonSOZwholeSum = zeros(length(HFO_interval_SD_nonSOZwhole),1);
for i = 1 : length(HFO_interval_SD_nonSOZwhole)
    indicator = length(HFO_interval_SD_nonSOZwhole{i,1}) + length(HFO_interval_SD_nonSOZwhole{i,2});
    switch indicator
        case 0
            HFO_interval_SD_nonSOZwholeSum(i) = NaN;
        case 1
            if length(HFO_interval_SD_nonSOZwhole{i,1}) == 1
                HFO_interval_SD_nonSOZwholeSum(i) = HFO_interval_SD_nonSOZwhole{i,1};
            else
                HFO_interval_SD_nonSOZwholeSum(i) = HFO_interval_SD_nonSOZwhole{i,2};
            end
        case 2
            HFO_interval_SD_nonSOZwholeSum(i) = mean([HFO_interval_SD_nonSOZwhole{i,1},HFO_interval_SD_nonSOZwhole{i,2}]);
    end
end


p = ranksum(HFO_interval_SD_SOZwholeSum,HFO_interval_SD_nonSOZwholeSum)
diff = mean(HFO_interval_SD_SOZwholeSum(find(isnan(HFO_interval_SD_SOZwholeSum)~=1)))-mean(HFO_interval_SD_nonSOZwholeSum(find(isnan(HFO_interval_SD_nonSOZwholeSum)~=1)))

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\whole_data')
save('rhythmicSD_SOZ_whole.mat','HFO_interval_SD_SOZwholeSum')
save('rhythmicSD_nonSOZ_whole.mat','HFO_interval_SD_nonSOZwholeSum')
%% rhythmic_skewness whole
% SOZ
HFO_interval_Skew_SOZwhole = cell(size(HFO_interval_SOZWholeFinal,1),2);
HFO_interval_Skew_SOZwhole(:,1) = HFO_interval_SOZWholeFinal(:,3);
HFO_interval_Skew_SOZwhole(:,2) = HFO_interval_SOZWholeFinal(:,6);
HFO_interval_Skew_SOZwholeSum = zeros(length(HFO_interval_Skew_SOZwhole),1);
for i = 1 : length(HFO_interval_Skew_SOZwhole)
    indicator = length(HFO_interval_Skew_SOZwhole{i,1}) + length(HFO_interval_Skew_SOZwhole{i,2});
    switch indicator
        case 0
            HFO_interval_Skew_SOZwholeSum(i) = NaN;
        case 1
            if length(HFO_interval_Skew_SOZwhole{i,1}) == 1
                HFO_interval_Skew_SOZwholeSum(i) = HFO_interval_Skew_SOZwhole{i,1};
            else
                HFO_interval_Skew_SOZwholeSum(i) = HFO_interval_Skew_SOZwhole{i,2};
            end
        case 2
            HFO_interval_Skew_SOZwholeSum(i) = mean([HFO_interval_Skew_SOZwhole{i,1},HFO_interval_Skew_SOZwhole{i,2}]);
    end
end

% nonSOZ
HFO_interval_Skew_nonSOZwhole = cell(size(HFO_interval_nonSOZWholeFinal,1),2);
HFO_interval_Skew_nonSOZwhole(:,1) = HFO_interval_nonSOZWholeFinal(:,3);
HFO_interval_Skew_nonSOZwhole(:,2) = HFO_interval_nonSOZWholeFinal(:,6);
HFO_interval_Skew_nonSOZwholeSum = zeros(length(HFO_interval_Skew_nonSOZwhole),1);
for i = 1 : length(HFO_interval_Skew_nonSOZwhole)
    indicator = length(HFO_interval_Skew_nonSOZwhole{i,1}) + length(HFO_interval_Skew_nonSOZwhole{i,2});
    switch indicator
        case 0
            HFO_interval_Skew_nonSOZwholeSum(i) = NaN;
        case 1
            if length(HFO_interval_Skew_nonSOZwhole{i,1}) == 1
                HFO_interval_Skew_nonSOZwholeSum(i) = HFO_interval_Skew_nonSOZwhole{i,1};
            else
                HFO_interval_Skew_nonSOZwholeSum(i) = HFO_interval_Skew_nonSOZwhole{i,2};
            end
        case 2
            HFO_interval_Skew_nonSOZwholeSum(i) = mean([HFO_interval_Skew_nonSOZwhole{i,1},HFO_interval_Skew_nonSOZwhole{i,2}]);
    end
end


p = ranksum(HFO_interval_Skew_SOZwholeSum,HFO_interval_Skew_nonSOZwholeSum)
diff = mean(HFO_interval_Skew_SOZwholeSum(find(isnan(HFO_interval_Skew_SOZwholeSum)~=1)))-mean(HFO_interval_Skew_nonSOZwholeSum(find(isnan(HFO_interval_Skew_nonSOZwholeSum)~=1)))

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\whole_data')
save('rhythmicSkew_SOZ_whole.mat','HFO_interval_Skew_SOZwholeSum')
save('rhythmicSkew_nonSOZ_whole.mat','HFO_interval_Skew_nonSOZwholeSum')
%% rhythmic_kurtosis whole
% SOZ
HFO_interval_Kurt_SOZwhole = cell(size(HFO_interval_SOZWholeFinal,1),2);
HFO_interval_Kurt_SOZwhole(:,1) = HFO_interval_SOZWholeFinal(:,4);
HFO_interval_Kurt_SOZwhole(:,2) = HFO_interval_SOZWholeFinal(:,7);
HFO_interval_Kurt_SOZwholeSum = zeros(length(HFO_interval_Kurt_SOZwhole),1);
for i = 1 : length(HFO_interval_Kurt_SOZwhole)
    indicator = length(HFO_interval_Kurt_SOZwhole{i,1}) + length(HFO_interval_Kurt_SOZwhole{i,2});
    switch indicator
        case 0
            HFO_interval_Kurt_SOZwholeSum(i) = NaN;
        case 1
            if length(HFO_interval_Kurt_SOZwhole{i,1}) == 1
                HFO_interval_Kurt_SOZwholeSum(i) = HFO_interval_Kurt_SOZwhole{i,1};
            else
                HFO_interval_Kurt_SOZwholeSum(i) = HFO_interval_Kurt_SOZwhole{i,2};
            end
        case 2
            HFO_interval_Kurt_SOZwholeSum(i) = mean([HFO_interval_Kurt_SOZwhole{i,1},HFO_interval_Kurt_SOZwhole{i,2}]);
    end
end

% nonSOZ
HFO_interval_Kurt_nonSOZwhole = cell(size(HFO_interval_nonSOZWholeFinal,1),2);
HFO_interval_Kurt_nonSOZwhole(:,1) = HFO_interval_nonSOZWholeFinal(:,4);
HFO_interval_Kurt_nonSOZwhole(:,2) = HFO_interval_nonSOZWholeFinal(:,7);
HFO_interval_Kurt_nonSOZwholeSum = zeros(length(HFO_interval_Kurt_nonSOZwhole),1);
for i = 1 : length(HFO_interval_Kurt_nonSOZwhole)
    indicator = length(HFO_interval_Kurt_nonSOZwhole{i,1}) + length(HFO_interval_Kurt_nonSOZwhole{i,2});
    switch indicator
        case 0
            HFO_interval_Kurt_nonSOZwholeSum(i) = NaN;
        case 1
            if length(HFO_interval_Kurt_nonSOZwhole{i,1}) == 1
                HFO_interval_Kurt_nonSOZwholeSum(i) = HFO_interval_Kurt_nonSOZwhole{i,1};
            else
                HFO_interval_Kurt_nonSOZwholeSum(i) = HFO_interval_Kurt_nonSOZwhole{i,2};
            end
        case 2
            HFO_interval_Kurt_nonSOZwholeSum(i) = mean([HFO_interval_Kurt_nonSOZwhole{i,1},HFO_interval_Kurt_nonSOZwhole{i,2}]);
    end
end


p = ranksum(HFO_interval_Kurt_SOZwholeSum,HFO_interval_Kurt_nonSOZwholeSum)
diff = mean(HFO_interval_Kurt_SOZwholeSum(find(isnan(HFO_interval_Kurt_SOZwholeSum)~=1)))-mean(HFO_interval_Kurt_nonSOZwholeSum(find(isnan(HFO_interval_Kurt_nonSOZwholeSum)~=1)))

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\whole_data')
save('rhythmicKurt_SOZ_whole.mat','HFO_interval_Kurt_SOZwholeSum')
save('rhythmicKurt_nonSOZ_whole.mat','HFO_interval_Kurt_nonSOZwholeSum')
%% PAC whole
% SOZ
HFO_PAC_SOZwhole = cell(size(HFO_pac_SOZWholeFinal,1),2);
HFO_PAC_SOZwhole(:,1) = HFO_pac_SOZWholeFinal(:,2);
HFO_PAC_SOZwhole(:,2) = HFO_pac_SOZWholeFinal(:,3);
HFO_PAC_SOZwholeSum = zeros(length(HFO_PAC_SOZwhole),1);
for i = 1 : length(HFO_PAC_SOZwhole)
    indicator = length(HFO_PAC_SOZwhole{i,1}) + length(HFO_PAC_SOZwhole{i,2});
    switch indicator
        case 0
            HFO_PAC_SOZwholeSum(i) = NaN;
        case 1
            if length(HFO_PAC_SOZwhole{i,1}) == 1
                HFO_PAC_SOZwholeSum(i) = HFO_PAC_SOZwhole{i,1};
            else
                HFO_PAC_SOZwholeSum(i) = HFO_PAC_SOZwhole{i,2};
            end
        case 2
            HFO_PAC_SOZwholeSum(i) = mean([HFO_PAC_SOZwhole{i,1},HFO_PAC_SOZwhole{i,2}]);
    end
end

% nonSOZ
HFO_PAC_nonSOZwhole = cell(size(HFO_pac_nonSOZWholeFinal,1),2);
HFO_PAC_nonSOZwhole(:,1) = HFO_pac_nonSOZWholeFinal(:,2);
HFO_PAC_nonSOZwhole(:,2) = HFO_pac_nonSOZWholeFinal(:,3);
HFO_PAC_nonSOZwholeSum = zeros(length(HFO_PAC_nonSOZwhole),1);
for i = 1 : length(HFO_PAC_nonSOZwhole)
    indicator = length(HFO_PAC_nonSOZwhole{i,1}) + length(HFO_PAC_nonSOZwhole{i,2});
    switch indicator
        case 0
            HFO_PAC_nonSOZwholeSum(i) = NaN;
        case 1
            if length(HFO_PAC_nonSOZwhole{i,1}) == 1
                HFO_PAC_nonSOZwholeSum(i) = HFO_PAC_nonSOZwhole{i,1};
            else
                HFO_PAC_nonSOZwholeSum(i) = HFO_PAC_nonSOZwhole{i,2};
            end
        case 2
            HFO_PAC_nonSOZwholeSum(i) = mean([HFO_PAC_nonSOZwhole{i,1},HFO_PAC_nonSOZwhole{i,2}]);
    end
end


p = ranksum(HFO_PAC_SOZwholeSum,HFO_PAC_nonSOZwholeSum)
diff = mean(HFO_PAC_SOZwholeSum(find(isnan(HFO_PAC_SOZwholeSum)~=1)))-mean(HFO_PAC_nonSOZwholeSum(find(isnan(HFO_PAC_nonSOZwholeSum)~=1)))

cd('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\data\whole_data')
save('PAC_SOZ_whole.mat','HFO_PAC_SOZwholeSum')
save('PAC_nonSOZ_whole.mat','HFO_PAC_nonSOZwholeSum')
%% ML

PredictIndicator_nonSOZ = [HFO_stereo_R_nonSOZwholeSum,HFO_interval_Skew_nonSOZwholeSum,HFO_interval_Kurt_nonSOZwholeSum,HFO_PAC_nonSOZwholeSum];
PredictIndicator_SOZ = [HFO_stereo_R_SOZwholeSum,HFO_interval_Skew_SOZwholeSum,HFO_interval_Kurt_SOZwholeSum,HFO_PAC_SOZwholeSum];
PredictIndicator_nonSOZ = PredictIndicator_nonSOZ(all(~isnan(PredictIndicator_nonSOZ),2),:);
PredictIndicator_SOZ = PredictIndicator_SOZ(all(~isnan(PredictIndicator_SOZ),2),:);
% 0: nonSOZ,1: SOZ
PredictIndicator_nonSOZ(:,5) = 0;
PredictIndicator_SOZ(:,5) = 1;
trainMatrix = [PredictIndicator_nonSOZ;PredictIndicator_SOZ];

%% violinplot

addpath(genpath('C:\Users\LiZilin\Desktop\click-here-to -start-involution\HFO\Violinplot-Matlab-master'))
% stereoR
stereoR = [HFO_stereo_R_nonSOZwholeSum;HFO_stereo_R_SOZwholeSum];
title_stereoR = cell(length(HFO_stereo_R_nonSOZwholeSum)+length(HFO_stereo_R_SOZwholeSum),1);
title_stereoR(1:length(HFO_stereo_R_nonSOZwholeSum)) = cellstr('nonSOZ');
title_stereoR(length(HFO_stereo_R_nonSOZwholeSum)+1:end) = cellstr('SOZ');
figure
violinplot(stereoR,title_stereoR)
ylabel('R value')
title('Stereotyped R value')
% kurtosis
kurt = [HFO_interval_Kurt_nonSOZwholeSum;HFO_interval_Kurt_SOZwholeSum];
title_interval_Kurt = cell(length(HFO_interval_Kurt_nonSOZwholeSum)+length(HFO_interval_Kurt_SOZwholeSum),1);
title_interval_Kurt(1:length(HFO_interval_Kurt_nonSOZwholeSum)) = cellstr('nonSOZ');
title_interval_Kurt(length(HFO_interval_Kurt_nonSOZwholeSum)+1:end) = cellstr('SOZ');
figure
violinplot(kurt,title_interval_Kurt)
ylabel('kurtosis')
title('Interval Kurtosis')
% skewness
skew = [HFO_interval_Skew_nonSOZwholeSum;HFO_interval_Skew_SOZwholeSum];
title_interval_Skew = cell(length(HFO_interval_Skew_nonSOZwholeSum)+length(HFO_interval_Skew_SOZwholeSum),1);
title_interval_Skew(1:length(HFO_interval_Skew_nonSOZwholeSum)) = cellstr('nonSOZ');
title_interval_Skew(length(HFO_interval_Skew_nonSOZwholeSum)+1:end) = cellstr('SOZ');
figure
violinplot(skew,title_interval_Skew)
ylabel('skewness')
title('Interval Skewness')
% pac
pac = [HFO_PAC_nonSOZwholeSum;HFO_PAC_SOZwholeSum];
title_pac = cell(length(HFO_PAC_nonSOZwholeSum)+length(HFO_PAC_SOZwholeSum),1);
title_pac(1:length(HFO_PAC_nonSOZwholeSum)) = cellstr('nonSOZ');
title_pac(length(HFO_PAC_nonSOZwholeSum)+1:end) = cellstr('SOZ');
figure
violinplot(pac,title_pac)
ylabel('MI')
title('Phase Amplitude Coupling')
%%
SOZLabel = HFO_pac_SOZWholeFinal(:,1);
nonSOZLabel = HFO_pac_nonSOZWholeFinal(:,1);
nonSOZLabel = nonSOZLabel(all(~isnan(PredictIndicator_nonSOZ),2),:);

